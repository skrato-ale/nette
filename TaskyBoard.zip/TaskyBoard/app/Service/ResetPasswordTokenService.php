<?php

namespace App\Service;

use App\Dao\Model\ResetPasswordToken;
use App\Dao\ResetPasswordTokenDAO;
use DateTime;

class ResetPasswordTokenService
{
    public function __construct(
        private ResetPasswordTokenDAO $resetPasswordTokenDAO
    )
    { 
    }

    public function createToken(int $userId)
    {
        $encryption_key = ; 

        $expires = new DateTime('+15 minutes');

        $token = $this->generateResetToken($userId, $encryption_key, $expires);

        $data = [
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => $expires,
            'created_at' => new DateTime(),
        ];

        return $this->resetPasswordTokenDAO->insert($data);
    }


    public function generateResetToken($userId, $encryption_key, DateTime $expires) {
        $expiration = $expires->format(DateTime::ATOM);
    
        $data = [
            'user_id' => $userId,
            'exp' => $expiration
        ];
    
        $plaintext = json_encode($data);
        $cipher = 'aes-256-cbc';
        
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));
    
        $encryptedToken = openssl_encrypt($plaintext, $cipher, $encryption_key, 0, $iv);
        
        $encryptedToken = base64_encode($encryptedToken . '::' . base64_encode($iv));
    
        return $encryptedToken;
    }


    public function decryptResetToken($token) {
        $encryption_key = 'encryption_key'; // TODO michal Add to env
        $cipher = 'aes-256-cbc';
        
        list($encrypted_data, $iv) = explode('::', base64_decode($token), 2);
        
        $iv = base64_decode($iv);
        
        $decryptedToken = openssl_decrypt($encrypted_data, $cipher, $encryption_key, 0, $iv);
    
        return json_decode($decryptedToken, true);
    }
    
    
    public function isTokenValid($data) {
        if (!isset($data['user_id']) || !isset($data['exp'])) {
            return false;
        }
    
        $expiration = new DateTime($data['exp']);
        $now = new DateTime();
    
        return $expiration >= $now;
    }


    public function IsUsed(string $token): bool
    {
        $resetPasswordToken = ResetPasswordToken::from($this->resetPasswordTokenDAO->findByToken($token));

        return $resetPasswordToken->is_used;
    }


    public function setIsUsed(string $token): void
    {
        $resetPasswordToken = $this->resetPasswordTokenDAO->findBy([
            'token' => $token
        ]);

        $this->resetPasswordTokenDAO->update($resetPasswordToken, [
            'is_used' => true
        ]);
    }
    
}