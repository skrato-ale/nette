<?php

namespace App\Service;

use App\Dao\Model\User;
use App\Dao\UserDAO;
use App\Enums\UserStatusEnum;
use Nette\Utils\Strings;

class UserService
{
    public function __construct(
        public UserDAO               $userDAO,
        public \Nette\Security\User  $netteUser

    )
    {
    }

    public function update(User $user): User
    {
        $user->updateRow( $this->userDAO->find( $user->id ));

        return $user;
    }

    public function delete( User $user, string $reason, bool $admin = false ) : void
    {
        if( $user->deleted ) {
            return;
        }

        $user->setFromArray([
            'deleted' => 1,
            'status' => UserStatusEnum::DELETED,
            'reason_delete_account' => $reason
        ]);

        $this->update( $user );

        $this->eventManager->trigger( $this, 'delete', $user, $reason, $admin );
    }


    public function switchActive($dao, $value, $id)
    {
        $entity = $dao->find($id);
        $entity->update(['active' => $value]);
    }


    public static function sanitizeNick(string $nick): string
    {
        return strtolower(Strings::webalize($nick));
    }

}
