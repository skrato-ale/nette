<?php

namespace App\Service;

use App\Dao\TaskCommentDAO;
use App\Dao\TaskDAO;
use App\Dao\TaskHistoryDAO;
use App\Dao\UserDAO;
use App\Enums\TaskSelectTypeEnum;
use App\Enums\TaskStateEnum;
use Nette;
use Nette\Database\Table\ActiveRow;
use Nette\DI\Attributes\Inject;
use Nette\Utils\DateTime;

class TaskService
{
    #[ Inject ]
    public Nette\Security\User $user;


    public function __construct(
        public TaskDAO  $taskDAO
    )
    {
    }

    public function getAllForCalendarUser($userId, bool $removed = false)
    {
        $tasks = $this->taskDAO->getTable()
            ->select('id, name, start_date, start_time, created_by_id, task_state, assigned_to_id')
            ->where('start_date IS NOT NULL')
            ->where('assigned_to_id', $userId)
            ->where('removed', $removed)
            ->fetchAll();

        return $this->mapTasksForCalendar($tasks);
    }
    

    public function getAllForCalendar(bool $removed = false): array
    {
        $tasks = $this->taskDAO->findBy(['removed' => $removed, 'start_date NOT' => null, 'task_select_type' => TaskSelectTypeEnum::TASK])->fetchAll();

        return $this->mapTasksForCalendar($tasks);
    }


    public function getAllByUserIdsForCalendar(array $ids, bool $removed = false): array
    {
        $tasks = $this->taskDAO->findBy(['assigned_to_id IN' => $ids, 'removed' => $removed, 'start_date NOT' => null, 'task_select_type' => TaskSelectTypeEnum::TASK])->fetchAll();

        return $this->mapTasksForCalendar($tasks);
    }


    public function mapTasksForCalendar($tasks) 
    {
        return array_map(function (ActiveRow $task) {
            return [
                'id' => $task->id,
                'user' => $task->assigned_to ? $task->assigned_to->nick : '',
                'name' => $task->name ?: 'Bez názvu',
                'start_date' => $task->start_date,
                'color' => TaskStateEnum::getCalendarBackgroundColor($task->task_state)
            ];
        }, $tasks);
    }
}
