<?php declare(strict_types=1);

namespace App\Model\Address;

use App\Helpers\CastTry;
use App\Model\Base\RevisionManager;
use Nette\Database\SqlLiteral;
use Nette\DI\Attributes\Inject;
use Nette\NotImplementedException;
use Nette\Schema\Expect;

class AddressManager extends RevisionManager
{
    #[ Inject ]
    public AssignManager
        $assignManager;


    public array
        $lengths = [
            'query'     => 500,
            'meta'      => 2000,
            'country'   => 100,
            'city'      => 100,
            'street'    => 250,
            'zip'       => 20,
        ];

    public array
        $decimals = [
            'long'      => 8,
        ];

    public array
        $values = [
            'long'      => [ -180, 180 ],
            'lat'       => [ -90, 90 ],
        ];


    public function create( array $values ) : AddressRow
    {
        $values = $this->prepare( $values );

        $this->setPoint( null, $values );
        $this->setVersion( null, $values );
        $this->setRelate( $values );

        $address = $this->explorer->table('address')->insert( $values );

        $this->historyManager->createHash( $address, $values );

        return $address;
    }


    public function update( AddressRow $address, array $values ) : bool
    {
        $values = $this->compare( $address, $values );

        if( !$values ) {
            return false;
        }

        $this->setPoint( $address, $values );
        $this->setVersion( $address, $values );
        $this->setRelate( $values );

        $update = $address->update( $values );

        $this->historyManager->createHash( $address, $values );

        return $update;
    }


    public function delete( AddressRow $address ) : void
    {
        throw new NotImplementedException('Todo later.');
    }


    public function handle( AddressRow | null $address, array $values ) : AddressRow | null
    {
        if( $address ) {
            $this->update( $address, $values );

            return null;
        } elseif( $this->isFilled( $values )) {
            return $this->create( $values );
        } else {
            return null;
        }
    }


    public function assign( AddressRow $address ) : bool
    {
        if( !$address->meta ) {
            return false;
        }

        [ $country, $region, $city ] = $this->assignManager->searchList( $address->meta );

        if( $address->country_id === $country?->id and $address->region_id === $region?->id and $address->city_id === $city?->id ) {
            return false;
        }

        return $address->update([
            'country_id'    => $country?->id,
            'region_id'     => $region?->id,
            'city_id'       => $city?->id,
        ]);
    }


    public function clone( AddressRow $parent ) : AddressRow
    {
        $values = $parent->toArray();
        $values['version'] = 1;

        unset( $values['id'] );

        $address = $this->explorer->table('address')->insert( $values );

        $this->historyManager->createHash( $address, $values );

        return $address;
    }


    protected function setRelate( array &$values ) : void
    {
        if( !array_key_exists('meta', $values )) {
            return;
        }

        [ $country, $region, $city ] = $this->assignManager->searchList( $values['meta'] );

        $values['country_id'] = $country?->id;
        $values['region_id'] = $region?->id;
        $values['city_id'] = $city?->id;
    }


    protected function setPoint( AddressRow | null $address, array &$values ) : void
    {
        $hasLong = array_key_exists('long', $values );
        $hasLat = array_key_exists('lat', $values );

        if( !$hasLong and !$hasLat ) {
            return;
        }

        $long = $hasLong ? $values['long'] : $address?->long;
        $lat = $hasLat ? $values['lat'] : $address?->lat;

        if( $long !== null and $lat !== null and $long !== 0. and $lat !== 0. ) {
            $point = new SqlLiteral('ST_POINTFROMTEXT(?)', ["POINT({$long} {$lat})"]);
        } else {
            $point = null;
        }

        $values['point'] = $point;
    }


    protected function getStructure() : array
    {
        return [
            'query'     => Expect::unicode()->nullable()->max( $this->lengths['query'] ),
            'meta'      => Expect::unicode()->nullable()->max( $this->lengths['meta'] ),
            'street'    => Expect::unicode()->nullable()->max( $this->lengths['street'] ),
            'country'   => Expect::unicode()->nullable()->max( $this->lengths['country'] ),
            'city'      => Expect::unicode()->nullable()->max( $this->lengths['city'] ),
            'zip'       => Expect::unicode()->nullable()->max( $this->lengths['zip'] ),
            'long'      => Expect::float()->nullable()->min( $this->values['long'][0] )->max( $this->values['long'][1] )->before( CastTry::float(...))->transform( $this->doRound(...)),
            'lat'       => Expect::float()->nullable()->min( $this->values['lat'][0] )->max( $this->values['lat'][1] )->before( CastTry::float(...))->transform( $this->doRound(...)),
        ];
    }


    protected function doRound( float | null $value ) : float | null
    {
        if( $value !== null ) {
            $value = round( $value, $this->decimals['long'] );
        }

        return $value;
    }
}
