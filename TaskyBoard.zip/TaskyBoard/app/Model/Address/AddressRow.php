<?php declare(strict_types=1);

namespace App\Model\Address;

use App\Model\Base\VersionRow;
use Nette\Database\Table\ActiveRow;

/**
 * @property string | null $query
 * @property string | null $meta
 *
 * @property string | null $country
 * @property string | null $city
 * @property string | null $street
 * @property string | null $zip
 *
 * @property float | null $long
 * @property float | null $lat
 *
 * @property string | null $point
 */
class AddressRow extends VersionRow
{
    const TABLE = 'address';


    public function getMappedCountry() : ActiveRow | null
    {
        return $this->ref('address_country', 'country_id');
    }


    public function getMappedRegion() : ActiveRow | null
    {
        return $this->ref('address_region', 'region_id');
    }


    public function getMappedCity() : ActiveRow | null
    {
        return $this->ref('address_city', 'city_id');
    }
}
