<?php declare(strict_types=1);

namespace App\Model\Task;

use App\Enums\TaskSelectTypeEnum;
use App\Model\Base\PrimaryRow;

class NoteManager extends BaseManager
{
    function create( PrimaryRow $entity, array $values ) : TaskRow
    {
        $values = $this->prepare( $values );

        $this->setDefaults( $values );
        $this->setRelations( $entity, $values );
        $this->setVersion( null, $values );

        $task = $this->explorer->table('task')->insert( $values );

        $this->historyManager->createHash( $task, $values );

        return $task;
    }


    public function update( TaskRow $task, array $values ) : bool
    {
        $this->verify( $task );

        $values = $this->compare( $task, $values );

        if( !$values ) {
            return false;
        }

        $this->setVersion( $task, $values );

        $update = $task->update( $values );

        $this->historyManager->createHash( $task, $values );

        return $update;
    }


    protected function getTaskType() : int
    {
        return TaskSelectTypeEnum::NOTE;
    }
}