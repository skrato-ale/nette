<?php declare(strict_types=1);

namespace App\Model\Task;

use App\Enums\TaskSelectTypeEnum;
use App\Model\Base\VersionRow;
use Nette\Utils\DateTime;

/**
 * @property int | null     $created_by_id
 * @property int | null     $assigned_to_id
 * @property int | null     $task_to_user_id
 *
 * @property string | null  $name
 * @property string         $description
 *
 * @property int | null     $type <= deprecated, use contact_type column
 * @property int | null     $contact_type
 * @property int | null     $task_state
 *
 * @property DateTime           $created
 * @property DateTime | null    $start_date
 * @property DateTime | null    $start_time <= deprecated, use start_date column
 *
 * @property int            $removed
 * @property int | null     $next_contact_type
 * @property int | null     $task_select_type
 */
class TaskRow extends VersionRow
{
    const TABLE = 'task';

    const
        PRIORITY_LOW    = 1,
        PRIORITY_MEDIUM = 2,
        PRIORITY_HIGH   = 3;

    private static array $priorityNames = [
        self::PRIORITY_LOW    => 'Low',
        self::PRIORITY_MEDIUM => 'Medium',
        self::PRIORITY_HIGH   => 'High',
    ];

    function isTask() : bool
    {
        return $this->task_select_type === TaskSelectTypeEnum::TASK;
    }


    function isNote() : bool
    {
        return $this->task_select_type === TaskSelectTypeEnum::NOTE;
    }


    public static function getPriorityNames(): array
    {
        return self::$priorityNames;
    }
}