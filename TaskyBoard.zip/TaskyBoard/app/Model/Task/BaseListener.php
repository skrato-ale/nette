<?php declare(strict_types=1);

namespace App\Model\Task;

use Nette\Application\LinkGenerator;
use Nette\DI\Attributes\Inject;

class BaseListener
{
    #[ Inject ]
    public LinkGenerator
        $linkGenerator;

}