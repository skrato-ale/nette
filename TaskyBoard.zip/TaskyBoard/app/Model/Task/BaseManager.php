<?php declare( strict_types=1 );

namespace App\Model\Task;

use App\Enums\TaskTypeEnum;
use App\Model\Base\PrimaryRow;
use App\Model\Base\RevisionManager;
use App\Model\User\UserRow;
use Nette\DI\Attributes\Inject;
use Nette\InvalidArgumentException;
use Nette\Schema\Expect;
use Nette\Security\User;
use Nette\Utils\DateTime;

abstract class BaseManager extends RevisionManager
{
    #[ Inject ]
    public User
        $session;


    public array
        $lengths = [
            'name'          => 250,
            'description'   => 50000,
        ];


    public function find( int $id ) : TaskRow | null
    {
        return $this->explorer->table( TaskRow::TABLE )->get( $id );
    }


    public function delete( TaskRow $task ) : bool
    {
        $this->verify( $task );

        if( $task->removed ) {
            return false;
        }

        return $task->update([
            'removed'       => 1,
        ]);
    }


    protected function verify( TaskRow $task ) : void
    {
        if( $task->task_select_type !== $this->getTaskType() ) {
            throw new InvalidArgumentException("Wrong type.");
        }
    }


    protected function setDefaults( array &$values ) : void
    {
        $values += [
            'task_select_type'  => $this->getTaskType(),
            'created_by_id'     => $this->session->getId(),
            'created'           => new DateTime,
            'priority'          => TaskRow::PRIORITY_LOW,
            'removed'           => 0,
        ];
    }


    protected function setRelations( PrimaryRow | null $entity, array &$values ) : void
    {
        if( $entity === null ) {
            return;
        }

        $number = $entity->id;

        if( $entity instanceof UserRow ) {
            $column = 'task_to_user_id';
        } else {
            throw new InvalidArgumentException("Unknown entity.");
        }

        $values += [
            $column => $number,
        ];
    }


    protected function getStructure() : array
    {
        return [
            'name'          => Expect::unicode()->max( $this->lengths['name'] )->nullable(),
            'description'   => Expect::unicode()->max( $this->lengths['description'] ),
            'contact_type'  => Expect::anyOf( ...array_keys( TaskTypeEnum::getNames() )),
            'priority'      => Expect::anyOf( ...array_keys( TaskRow::getPriorityNames() )),
        ];
    }


    protected function getMandatory() : array | null
    {
        return [
            'description',
            'contact_type',
        ];
    }


    abstract protected function getTaskType() : int;
}
