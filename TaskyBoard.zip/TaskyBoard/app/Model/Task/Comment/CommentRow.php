<?php declare( strict_types=1 );

namespace App\Model\Task\Comment;

use App\Model\Base\PrimaryRow;
use Nette\Utils\DateTime;

/**
 * @property int $created_by_id
 * @property string $comment_text
 * @property DateTime $created
 */
class CommentRow extends PrimaryRow
{
    const TABLE = 'task_comment';
}