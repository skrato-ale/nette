<?php declare(strict_types=1);

namespace App\Model\Task\Comment;

use App\Model\Base\StrictManager;
use App\Model\Task\TaskRow;
use Nette\DI\Attributes\Inject;
use Nette\Schema\Expect;
use Nette\Security\User;
use Nette\Utils\DateTime;

class CommentManager extends StrictManager
{
    #[ Inject ]
    public User
        $session;


    public array
        $lengths = [
            'comment_text'  => 50_000,
        ];


    function create( TaskRow $task, array $values ) : CommentRow
    {
        $values = $this->prepare( $values );

        $values += [
            'task_id'       => $task->id,
            'created_by_id' => $this->session->getId(),
            'created'       => new DateTime,
        ];

        return $this->explorer->table( CommentRow::TABLE )->insert( $values );
    }


    protected function getStructure() : array
    {
        return [
            'comment_text'  => Expect::unicode()->max( $this->lengths['comment_text'] )
        ];
    }


    protected function getMandatory() : array | null
    {
        return [
            'comment_text',
        ];
    }
}
