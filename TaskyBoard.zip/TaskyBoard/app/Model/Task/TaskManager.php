<?php declare(strict_types=1);

namespace App\Model\Task;

use App\Enums\TaskSelectTypeEnum;
use App\Enums\TaskStateEnum;
use App\Enums\TaskTypeEnum;
use App\Model\Base\PrimaryRow;
use App\Model\User\UserRow;
use DateInterval;
use Nette\Schema\Expect;
use Nette\Utils\DateTime;

class TaskManager extends BaseManager
{
    public function create( PrimaryRow $entity, UserRow $user, array $values ) : TaskRow
    {
        $this->setStart( null, $values );

        $values = $this->prepare( $values );
        $values += $this->prepareJoins(['assigned_to_id' => $user ]);

        $this->setDefaults( $values );
        $this->setRelations( $entity, $values );
        $this->setVersion( null, $values );

        $task = $this->explorer->table('task')->insert( $values );

        $this->historyManager->createHash( $task, $values );

        return $task;
    }


    public function update( TaskRow $task, UserRow | false $user, array | false $values ) : bool
    {
        $this->verify( $task );

        if( $values ) {
            $this->setStart( $task, $values );
        }

        $values = $this->compare( $task, $values );
        $values += $this->compareJoins( $task, ['assigned_to_id' => $user ]);

        if( !$values ) {
            return false;
        }

        $this->setVersion( $task, $values );

        $update = $task->update( $values );

        $this->historyManager->createHash( $task, $values );

        return $update;
    }


    public function updateStatus( TaskRow $task, mixed $status ) : bool
    {
        return $this->update( $task, false, ['task_state' => $status ] );
    }


    protected function setDefaults( array &$values ) : void
    {
        parent::setDefaults( $values );

        $values += [
            'start_date'        => $this->getTaskStart(),
            'task_state'        => TaskStateEnum::NEW
        ];
    }


    protected function getStructure() : array
    {
        $structure = parent::getStructure();

        return $structure + [
            'start_date'        => Expect::type( DateTime::class ),
            'task_state'        => Expect::anyOf( ...array_keys( TaskStateEnum::getNames() )),
            'next_contact_type' => Expect::anyOf( ...array_keys( TaskTypeEnum::getNamesNextContact() )),
        ];
    }


    protected function getMandatory() : array | null
    {
        $mandatory = parent::getMandatory();

        return [
            'name',
            'next_contact_type',
            ...$mandatory,
        ];
    }


    public function getTaskStart() : DateTime
    {
        $date = new DateTime('today');
        $date->setTime( (int) date('H'), (int) date('i'));

        return $date;
    }


    protected function getTaskType() : int
    {
        return TaskSelectTypeEnum::TASK;
    }


    protected function setStart( TaskRow | null $task, array &$values ) : void
    {
        $date = $values['start_date'] ?? null;
        $time = $values['start_time'] ?? null;

        if( $date instanceof DateTime ) {
            $date = clone $date;
        }

        if( $date instanceof DateTime and $time instanceof DateInterval ) {
            $date->add( $time );
        } elseif( $task and $task->start_date ) {
            if( $date instanceof DateTime ) {
                [ $h, $i, $s ] = explode(':', $task->start_date->format('H:i:s'));

                $date->setTime( (int) $h, (int) $i, (int) $s );
            } elseif( $time instanceof DateInterval ) {
                $date = clone $task->start_date;
                $date->setTime( 0, 0, 0 );
                $date->add( $time );
            }
        }

        $values['start_date'] = $date;
    }
}
