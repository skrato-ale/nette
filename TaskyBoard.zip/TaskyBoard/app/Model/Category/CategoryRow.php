<?php declare(strict_types=1);

namespace App\Model\Category;

use App\Model\Base\PrimaryRow;

/**
 * @property int | null $t_parent_id
 *
 * @property string | null $name
 * @property string | null $subname
 * @property string | null $button_name
 * @property string | null $text
 * @property int | null $ord
 * 
 * @property int | null $t_right
 * @property int | null $t_left
 * @property int | null $t_level
 * 
 * @property string | null $translation_key
 * 
 */
class CategoryRow extends PrimaryRow
{
    const
        TABLE = 'category';

    const
        ID_ROOT = 1;


    public function getParent() : CategoryRow | null
    {
        return $this->ref( CategoryRow::TABLE, 't_parent_id');
    }


    /** @return CategoryRow[] */
    public function getChildren() : array
    {
        return $this->related( CategoryRow::TABLE, 't_parent_id')->fetchAll();
    }


    public function isRoot() : bool
    {
        return $this->id === self::ID_ROOT;
    }
}
