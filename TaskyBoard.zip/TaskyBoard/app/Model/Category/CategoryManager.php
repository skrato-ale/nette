<?php declare(strict_types=1);

namespace App\Model\Category;

use App\Model\Base\StrictManager;
use Nette\NotImplementedException;

class CategoryManager extends StrictManager
{
    /** @return CategoryRow[] */
    public function findAll() : array
    {
        $categories = $this->explorer->table( CategoryRow::TABLE )
            ->order('t_parent_id, ord')
            ->fetchAll();

        unset( $categories[ CategoryRow::ID_ROOT ] );

        return $categories;
    }


    /** @return array[] */
    public function findAllAssoc() : array
    {
        $categories = $this->findAll();

        $parents =
        $childs = [];

        foreach( $categories as $id => $category ) {
            if( $category->t_parent_id === CategoryRow::ID_ROOT ) {
                $parents[ $id ] = $category;
            } else {
                $childs[ $category->t_parent_id ][ $id ] = $category;
            }
        }

        return [ $categories, $parents, $childs ];
    }


    protected function getStructure() : array
    {
        throw new NotImplementedException;
    }
}
