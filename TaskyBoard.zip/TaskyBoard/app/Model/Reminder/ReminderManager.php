<?php declare(strict_types=1);

namespace App\Model\Reminder;

use App\Helpers\CastTry;
use App\Model\Base\StrictManager;
use App\Model\User\UserRow;
use Nette\InvalidStateException;
use Nette\Schema\Expect;
use Nette\Utils\DateTime;

class ReminderManager extends StrictManager
{
    public function create( UserRow $user, array $values ) : ReminderRow
    {
        $values = $this->prepare( $values );

        $this->setDefaults( $user, $values );
    
        return $this->explorer->table('user_reminder')->insert( $values );
    }


    public function delay( ReminderRow $reminder, DateTime $planned ) : bool
    {
        if( !$reminder->isWaiting() ) {
            throw new InvalidStateException("Not waiting.");
        }

        if( $reminder->planned >= $planned ) {
            return false;
        }

        return $reminder->update([
            'planned'   => $planned,
        ]);
    }


    public function cancel( ReminderRow $reminder ) : bool
    {
        if( !$reminder->isWaiting() ) {
            throw new InvalidStateException("Not waiting.");
        }

        return $reminder->update([
            'status'    => ReminderRow::STATUS_CANCELLED,
        ]);
    }
    

    public function cancelType( UserRow $user, int $type ) : int
    {
        /** @var ReminderRow[] $reminders */
        $reminders = $this->explorer->table('user_reminder')
            ->where('user_id = ?', $user->id )
            ->where('status = ?', ReminderRow::STATUS_WAITING )
            ->where('type = ?', $type )
            ->fetchAll();

        $cancel = 0;

        foreach( $reminders as $reminder ) {
            if( $this->cancel( $reminder )) {
                $cancel++;
            }
        }

        return $cancel;
    }


    public function dispatch( ReminderRow $reminder ) : bool
    {
        if( !$reminder->isWaiting() ) {
            throw new InvalidStateException("Not waiting.");
        }

        return $reminder->update([
            'status'        => ReminderRow::STATUS_SUBMITTED,
            'dispatched'    => new DateTime
        ]);
    }


    protected function setDefaults( UserRow $user, array &$values ) : void
    {
        $values += [
            'user_id' => $user->id,
            'status'  => ReminderRow::STATUS_WAITING,
            'round'   => 1,
            'created' => new DateTime,
        ];
    }


    protected function getStructure() : array
    {
        return [
            'type'      => Expect::anyOf( ReminderRow::TYPE_SIGNUP_NOT_COMPLETED, ReminderRow::TYPE_SIGNUP_NOT_SUBMITTED ),
            'planned'   => Expect::type( DateTime::class )->before( CastTry::date(...)),
        ];
    }


    protected function getMandatory() : array | null
    {
        return [
            'type',
            'planned'
        ];
    }
}
