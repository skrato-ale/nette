<?php declare(strict_types=1);

namespace App\Model\Reminder;

use App\Model\Base\PrimaryRow;
use App\Model\User\UserReference;
use Nette\Utils\DateTime;

/**
 * @property int                $type
 * @property int                $status
 * @property int                $round
 * @property DateTime           $created
 * @property DateTime | null    $planned
 * @property DateTime | null    $dispatched
 */
class ReminderRow extends PrimaryRow
{
    use UserReference;

    const TABLE = 'user_reminder';

    const
        TYPE_SIGNUP_NOT_COMPLETED  = 1,
        TYPE_SIGNUP_NOT_SUBMITTED  = 2;

    const
        STATUS_WAITING   = 1,
        STATUS_CANCELLED = 2,
        STATUS_SUBMITTED = 3;


    function isWaiting() : bool
    {
        return $this->status === self::STATUS_WAITING;
    }


    function isCancelled() : bool
    {
        return $this->status === self::STATUS_CANCELLED;
    }


    function isSubmitted() : bool
    {
        return $this->status === self::STATUS_SUBMITTED;
    }
}