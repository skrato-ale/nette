<?php declare(strict_types=1);

namespace App\Model\User;

use App\Enums\UserStatusEnum;
use App\Helpers\CastTry;
use App\Model\Base\RevisionManager;
use App\Service\ContactService;
use Nette\DI\Attributes\Inject;
use Nette\Schema\Expect;
use Nette\Utils\DateTime;

abstract class UserManager extends RevisionManager
{
    #[ Inject ]
    public ContactService
        $contactService;

    public bool
        $isNewPhone = false;

    public bool
        $isNewEmail = false;

    public bool
        $isNewEmailCopy = false;


    public array
        $limits = [
            'age'       => [ 18, 100 ],
        ];

    public array
        $lengths = [
            'nick'                  => [ 3, 20 ],
            'password'              => 250,
            'preferred_language'    => 20,
        ];

    public array
        $patterns = [
            'nick'      => '[a-zA-Z0-9]+(-[a-zA-Z0-9]+)*',
        ];


    public function find( int $id ) : UserRow | null
    {
        return $this->explorer->table( UserRow::TABLE )->get( $id );
    }


    public function findByNick( string $nick ) : UserRow | null
    {
        return $this->explorer->table( UserRow::TABLE )
            ->where('nick LIKE ?', Like::escape( $nick ))
            ->where('deleted = ?', 0 )
            ->fetch();
    }


    public function findByEmail( string $email ) : UserRow | null
    {
        return $this->explorer->table( UserRow::TABLE )
            ->where('email LIKE ?', Like::escape( $email ))
            ->where('deleted = ?', 0 )
            ->fetch();
    }


    protected function setDefaults( array &$values ) : void
    {
        $values['can_review'] ??= 1;

        $values['status'] = UserStatusEnum::FULL_REGISTERED;
        $values['created'] = new DateTime;
    }


    protected function setChanges( array &$values ) : void
    {
        $this->isNewPhone = isset( $values['phone'] );
        $this->isNewEmail = isset( $values['email'] );
        $this->isNewEmailCopy = isset( $values['email_cc'] );

        if( array_key_exists('phone', $values )) {
            $values['hash_phone'] = $this->contactService->getHash( $values['phone'] );
            $values['is_verified_phone'] = null;
        }

        if( array_key_exists('email', $values )) {
            $values['hash_email'] = $this->contactService->getHash( $values['email'] );
            $values['is_verified_email'] = null;
        }

        if( array_key_exists('email_cc', $values )) {
            $values['hash_email'] = $this->contactService->getHash( $values['email_cc'] );
            $values['is_verified_email'] = null;
        }
    }


    protected function getMandatory() : array | null
    {
        return [
            'role_id',

            'nick',
            'password',
        ];
    }


    protected function getStructure() : array
    {
        return [
            'role_id'               => Expect::int()->min( 1 )->before( CastTry::int(...)),
            'nick'                  => Expect::unicode()->min( $this->lengths['nick'][0] )->max( $this->lengths['nick'][1] )->pattern( $this->patterns['nick'] ),
            'password'              => Expect::unicode()->max( $this->lengths['password'] ),
            'birthdate'             => Expect::type( DateTime::class )->nullable()->assert( $this->isBirthValid(...), 'No children.'),
            'advertising_date_end'  => Expect::type( DateTime::class )->nullable(),
            'preferred_language'    => Expect::unicode()->nullable()->max( $this->lengths['preferred_language'] ),
            'preferred_country_id'  => Expect::int()->nullable()->min( 1 )->before( CastTry::int(...)),
            'preferred_currency_id' => Expect::int()->nullable()->min( 0 )->before( CastTry::int(...)),
            'is_phone_show_on_web'  => Expect::int()->min( 0 )->max( 1 )->before( CastTry::int(...)),
            'is_email_show_on_web'  => Expect::int()->min( 0 )->max( 1 )->before( CastTry::int(...)),
            'have_whatsapp'         => Expect::int()->min( 0 )->max( 1 )->before( CastTry::int(...)),
            'can_review'            => Expect::int()->min( 0 )->max( 1 )->before( CastTry::int(...)),
        ];
    }


    public function getBirthLimit() : array
    {
        return array_map( function( int $limit ) {
            return new DateTime("today -{$limit} years");
        }, $this->limits['age'] );
    }


    public function isBirthValid( DateTime | null $date ) : bool
    {
        if( !$date ) {
            return true;
        }

        [ $max, $min ] = $this->getBirthLimit();

        return $date >= $min and $date <= $max;
    }


    public function isEmailUnique( string | null $email, UserRow | null $exist ) : bool
    {
        if( $email === null ) {
            return true;
        }

        $match = $this->findByEmail( $email );

        return $match === null or $match->id === $exist?->id;
    }


    public function isNickUnique( string | null $nick, UserRow | null $exist ) : bool
    {
        if( $nick === null ) {
            return true;
        }

        $match = $this->findByNick( $nick );

        return $match === null or $match->id === $exist?->id;
    }
}
