<?php declare(strict_types=1);

namespace App\Model\User;

use App;
use App\Service\UserService;
use Nette\DI\Attributes\Inject;
use Nette\InvalidArgumentException;
use Nette\Security\User;
use Nette\Utils\DateTime;

class AdminUserManager extends UserManager
{
    #[ Inject ]
    public UserService
        $userService;

    #[ Inject ]
    public User
        $session;


    public function create( array $values ) : UserRow
    {
        $values = $this->prepare( $values );

        if( !$this->isEmailUnique( $values['email'] ?? null, null )) {
            throw new InvalidArgumentException("Duplicate email.");
        } elseif( !$this->isNickUnique( $values['nick'] ?? null, null )) {
            throw new InvalidArgumentException("Duplicate nick.");
        }

        $this->setDefaults( $values );
        $this->setChanges( $values );

        $entity = new App\Dao\Model\User;
        $entity->setFromArray( $values );

        return $this->explorer->table('user')->insert( $entity->toArray() );
    }


    public function update( UserRow &$user, array $values ) : bool
    {
        unset( $values['password'] );

        $values = $this->compare( $user, $values );

        if( !$values ) {
            return false;
        }

        if( !$this->isEmailUnique( $values['email'] ?? null, $user )) {
            throw new InvalidArgumentException("Duplicate email.");
        } elseif( !$this->isNickUnique( $values['nick'] ?? null, $user )) {
            throw new InvalidArgumentException("Duplicate nick.");
        }

        $this->setChanges( $values );

        $entity = App\Dao\Model\User::from( $user );
        $entity->setFromArray( $values );

        $this->userService->update( $entity );

        $user = $entity->_row;

        return true;
    }


    protected function setDefaults( array &$values ) : void
    {
        parent::setDefaults( $values );

        $values['created_by_id'] = $this->session->getId();
        $values['advertising_date_end'] = new DateTime;
    }


    protected function getMandatory() : array | null
    {
        $mandatory = parent::getMandatory();

        return [
            'email',
            ...$mandatory,
        ];
    }
}
