<?php declare(strict_types=1);

namespace App\Model\User;

use App\Dao\Model\User;
use App\Model\Base\PrimaryRow;
use App\Model\Entity\EntityRow;
use Nette\InvalidStateException;

/**
 * @todo add fields
 *
 * @property string | null $phone
 * @property string | null $email
 * @property string | null $email_cc
 */
class UserRow extends PrimaryRow
{
    const TABLE = 'user';


    function getEntity( bool $strict = false ) : EntityRow | null
    {
        if( $entity = User::findEntityRow( $this )) {
            return $entity;
        } elseif( $strict ) {
            throw new InvalidStateException("No entity.");
        } else {
            return null;
        }
    }


    function getEntityObj( bool $strict = false ) : object | null
    {
        if( $entity = User::findEntity( $this )) {
            return $entity;
        } elseif( $strict ) {
            throw new InvalidStateException("No entity.");
        } else {
            return null;
        }
    }


    function getEntityOrSelf() : EntityRow | UserRow
    {
        $entity = $this->getEntity();

        return $entity ?? $this;
    }
}
