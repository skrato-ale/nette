<?php declare(strict_types=1);

namespace App;

use Nette\Application\Application;
use Nette\Application\PresenterFactory;
use Nette\Application\Request;
use Nette\Bootstrap\Configurator;
use Nette\DI\Container;

class Bootstrap
{
	public static function boot( bool $cli, bool $fix = false ): Container
	{
        $debug = false;

        if( $fix ) {
            $debug = true;
        } elseif( getenv('NETTE_DEBUG')) {
            $debug = true;
        } elseif( isset( $_GET['buggy'] ) and $_GET['buggy'] === self::getDebugQuery() ) {
            $debug = true;
        }

        $root = dirname( __DIR__ );

        $nette = new Configurator;
        $nette->addConfig( $root . '/config/common.neon');
        $nette->addConfig( $root . '/config/services.neon');
        $nette->addConfig( $root . '/config/local.neon');

        if( $cli ) {
            $nette->addConfig( $root . '/config/console.neon');
        }

        $nette->setDebugMode( $debug );
        $nette->setTempDirectory( $root . '/temp');
        $nette->enableTracy( $root . '/log');

        $nette->addStaticParameters([
            'appDir'    => $root . '/app',
            'wwwDir'    => $root . '/www',
        ]);

		$nette->createRobotLoader()
			->addDirectory( __DIR__ )
			->register();

		return $nette->createContainer();
	}


    public static function web() : Application
    {
        return self::boot( false )->getByType( Application::class );
    }


    public static function cli( bool $log = false ) : PresenterFactory
    {
        return self::boot( true, $log )->getService('application.presenterFactory');
    }


    public static function run( string $presenter, array $parameters = [] ) : void
    {
        $parameters['debug'] = (bool) ( $parameters['debug'] ?? false );

        self::cli( $parameters['debug'] )->createPresenter( $presenter )->run( new Request( $presenter, null, $parameters ));
    }


    public static function getDebugQuery() : string
    {
        return substr( md5('Salt&Shit' . floor( time() / 86400 )), 0, 6 );
    }
}
