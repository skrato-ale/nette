<?php

namespace App\Enums;

use App\Interfaces\IEnum;

class CountryEnum implements IEnum
{
	public const CZECHIA = 1;
	public const SLOVAKIA = 2;

	/** @var array<int,string>  */
	private static array $names = [
		self::CZECHIA => 'enum.country.czechia',
		self::SLOVAKIA => 'enum.country.slovakia'
	];

	/** @return array<int,string> */
	public static function getNames() : array
	{
		return self::$names;
	}

	public static function getName($key) : ?string
	{
		return self::$names[$key] ?? null;
	}

	public static function is(?int $key) : bool
	{
		return isset(self::$names[$key]);
	}
}