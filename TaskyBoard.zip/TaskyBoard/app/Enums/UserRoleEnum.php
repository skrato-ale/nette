<?php

namespace App\Enums;

use App\Interfaces\IEnum;

class UserRoleEnum implements IEnum
{
	public const ROLE_CUSTOMER = 4;
	public const ROLE_PARTNER = 12;

	/** @var array<int,string>  */
    private static array $names = [
        self::ROLE_CUSTOMER => 'customer',
        self::ROLE_PARTNER => 'partner'
    ];

    /** @return array<int,string> */
    public static function getNames() : array
    {
        return self::$names;
    }

    public static function getName($key) : ?string
    {
        return self::$names[$key] ?? null;
    }

    public static function is($key) : bool
    {
        return isset(self::$names[$key]);
    }



}

