<?php declare(strict_types=1);

namespace App\CronModule\Presenters;

use App\Dao\Model\User;
use App\Model\Reminder\ReminderManager;
use App\Model\Reminder\ReminderRow;
use App\Senders\UserSender;
use InvalidArgumentException;
use Nette\Database\Explorer;
use Nette\DI\Attributes\Inject;
use Nette\Utils\DateTime;

class SendReminderPresenter
{
    #[Inject]
    public ReminderManager $reminderManager;

    #[Inject]
    public UserSender $userSender;

    #[ Inject ]
    public Explorer
        $explorer;


    public function invoke() : void
    {
        /** @var ReminderRow|null $reminder */
        $reminder = $this->explorer->table( ReminderRow::TABLE )
            ->where('status = ?', ReminderRow::STATUS_WAITING )
            ->where('planned < ?', new DateTime )
            ->order('planned')
            ->fetch();

        if( $reminder ) {
            $this->dispatch( $reminder );
        }
    }


    private function dispatch( ReminderRow $reminder ) : void
    {
        $this->tryCatch( function() use( $reminder ) {
            $this->reminderManager->dispatch( $reminder );

            $user = User::from( $reminder->getUser() );

            if ($reminder->type === ReminderRow::TYPE_SIGNUP_NOT_COMPLETED) {
                $this->userSender->signupNotCompleted($user);
            } elseif ($reminder->type === ReminderRow::TYPE_SIGNUP_NOT_SUBMITTED) {
                $this->userSender->signupNotSubmitted($user);
            } else {
                throw new InvalidArgumentException("Invalid type value: \"{$reminder->type}\".");
            }
        });
    }
}
