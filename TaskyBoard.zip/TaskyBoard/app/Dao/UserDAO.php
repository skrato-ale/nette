<?php

namespace App\Dao;


use App\Enums\UserRoleEnum;
use App\Model\User\UserRow;
use Nette\Database\Table\ActiveRow;
use Nette\Database\Table\Selection;

class UserDAO extends BaseDAO
{
    protected const
        LIST_VALUE = 'nick',
        LIST_INDEX = 'id';

    protected string $table = 'user';

    public function findByLogin(string $login): ActiveRow | null
    {
        if( str_contains( $login, '@')) {
            return $this->findByEmail( $login );
        } else {
            return $this->findByNick( $login );
        }
    }

    public function findByEmail(string $login): ActiveRow | null
    {
        return $this->getTable()
            ->where('email LIKE ?', Like::escape( $login ))
            ->where('deleted = ?', 0 )
            ->fetch();
    }

    public function findByNick(string $login): ActiveRow | null
    {
        return $this->getTable()
            ->where('nick LIKE ?', Like::escape( $login ))
            ->where('deleted = ?', 0 )
            ->fetch();
    }

    public function findOneBy(array $criteria, string $order = null, bool $withDeleted = false): ?ActiveRow
    {
        if ($withDeleted === false) {
            if (!array_key_exists('deleted', $criteria)) {
                $criteria['deleted'] = false;
            }
        }

        return parent::findOneBy($criteria, $order);
    }

    public function queryAdmins() : Selection
    {
        $query = $this->getTable()
            ->where('role_id NOT IN ?', [ UserRoleEnum::ROLE_CUSTOMER, UserRoleEnum::ROLE_PARTNER ])
            ->where('deleted = ?', 0 );

        return $query;
    }


    public function listAdmins( string $value = self::LIST_VALUE, string $index = self::LIST_INDEX, string $order = null, mixed &$cache = null ) : array
    {
        $users = $cache ??= $this->queryAdmins()
            ->order( $order ?? $index )
            ->fetchAll();

        $items = [];

        foreach( $users as $user ) {
            $items[ $user->$index ] = $this->getOption( $user, $value );
        }

        return $items;
    }


    public function getOption( UserRow $user, string $value = self::LIST_VALUE ) : string
    {
        $role = $user->ref('role');

        return "{$user->$value}  (ID {$user->id}, {$role->name})";
    }

}
