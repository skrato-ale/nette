<?php

namespace App\Dao;

use Nette\Database\Table\Selection;

class TaskDAO extends BaseDAO
{
    protected string $table = 'task';

    public function getNotesForAdmin(int $userId)
    {
        $result = $this->getTable()
            ->where('task_to_user_id = ? OR created_by_id = ? OR assigned_to_id = ?', $userId, $userId, $userId);

        return $result->order('created DESC');
    }


    public function getNotesForUser(int $userId) : Selection
    {
        $condition = [];

        $condition['task_to_user_id = ?'] = $userId;
        $condition['created_by_id = ?'] = $userId;

        $result = $this->getTable()
            ->whereOr($condition);

        return $result->order('created DESC');
    }


}