<?php

namespace App\Dao;

class ResetPasswordTokenDAO extends BaseDAO
{
    protected string $table = 'reset_password_token';

    public function findByToken(string $token)
    {
        return $this->getTable()
                ->where('token', $token)
                ->fetch();
    }
}