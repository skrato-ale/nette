<?php

namespace App\Dao;

class TaskCommentDAO extends BaseDAO
{
    protected string $table = 'task_comment';

}