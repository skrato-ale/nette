<?php declare( strict_types=1 );

namespace App\Router;

use Nette\Caching\Cache;
use Nette\Caching\Storage;
use Nette\Database\Explorer;
use Nette\DI\Attributes\Inject;

class StaticRouteFactory
{
    #[ Inject ]
    public Explorer
        $explorer;


    private Cache
        $cache;

    private StaticRoute | null
        $route;


    private string
        $locale;


    public function __construct( Storage $storage, string $locale )
    {
        $this->cache = new Cache( $storage, 'StaticRouteFactory');

        $this->locale = $locale;
    }


    public function create() : StaticRoute
    {
        return $this->route = new StaticRoute( $this->explorer, $this->cache, 'App:Static', 'default', $this->locale );
    }


    public function flush() : void
    {
        $this->cache->remove( StaticRoute::CACHE_KEY );
    }


    public function getCache() : Cache
    {
        return $this->cache;
    }


    public function getLastRoute() : StaticRoute | null
    {
        return $this->route;
    }
}