<?php declare(strict_types=1);

namespace App\Router;

use Nette\Caching\Cache;
use Nette\Database\Explorer;
use Nette\Http\IRequest;
use Nette\Http\UrlScript;
use Nette\Routing\Router;

class StaticRoute implements Router
{
    const
        CACHE_KEY = 'schema';


    private Explorer
        $explorer;

    private Cache
        $cache;


    private string
        $presenter;

    private string
        $action;

    private string
        $locale;

    private string
        $current;

    private array | null
        $schema = null;

    private int | null
        $match = null;


    public function __construct( Explorer $explorer, Cache $cache, string $presenter, string $action, string $locale )
    {
        $this->explorer = $explorer;
        $this->cache = $cache;

        $this->presenter = $presenter;
        $this->action = $action;
        $this->locale =
        $this->current = $locale;
    }


    public function match( IRequest $request ) : array | null
    {
        $url = $request->getUrl();

        $path = $url->getPath();
        $base = $url->getBasePath();

        if( !str_starts_with( $path, $base )) {
            return null;
        }

        $path = rawurldecode( substr( $path, strlen( $base )));
        $data = explode('/', rtrim( $path, '/'));

        if(( $count = count( $data )) === 1 ) {
            $source = $data[0];
            $locale = $this->locale;
        } elseif( $count === 2 ) {
            $locale = $data[0];
            $source = $data[1];
        } else {
            return null;
        }

        $schema = $this->getUrlSchema();

        if( !isset( $schema['ls2r'][ $locale ][ $source ] )) {
            return null;
        }

        $this->match = $schema['ls2r'][ $locale ][ $source ];

        return [
            'presenter' => $this->presenter,
            'action'    => $this->action,
            'locale'    => $locale,
            'slug'      => $source,
        ] + $request->getQuery();
    }


    public function constructUrl( array $params, UrlScript $url ) : string | null
    {
        if(( $params['presenter'] ?? null ) !== $this->presenter or ( $params['action'] ?? $this->action ) !== $this->action ) {
            return null;
        }

        $slug = $params['slug'] ?? null;
        $code = $params['code'] ?? null;

        if( $slug === null and $code === null ) {
            return null;
        }

        $schema = $this->getUrlSchema();

        if( $code !== null ) {
            if( !isset( $schema['c2r'][ $code ] )) {
                return '#invalid-page-' . rawurlencode( $code );
            }

            $route = $schema['c2r'][ $code ];
            $lang = $params['locale'] ?? $this->current;

            if( !isset( $schema['lr2s'][ $lang ][ $route ] )) {
                return null;
            }

            $slug = $schema['lr2s'][ $lang ][ $route ];
        } else {
            $lang = $params['locale'] ?? $this->locale;
            $test = $this->current;

            if( $lang !== $test ) {
                if( !isset( $schema['ls2r'][ $test ][ $slug ] )) {
                    return null;
                }

                $route = $schema['ls2r'][ $test ][ $slug ];

                if( !isset( $schema['lr2s'][ $lang ][ $route ] )) {
                    return null;
                }

                $slug = $schema['lr2s'][ $lang ][ $route ];
            } else {
                if( !isset( $schema['ls2r'][ $lang ][ $slug ] )) {
                    return null;
                }
            }
        }

        unset( $params['presenter'], $params['action'], $params['locale'], $params['slug'], $params['code'] );

        $slug = rawurlencode( $slug );
        $lang = rawurlencode( $lang );

        $path = "{$url->getBaseUrl()}{$lang}/{$slug}/";

        if( $params ) {
            $query = http_build_query( $params, '', '&');

            if( $query !== '') {
                $path = "{$path}?{$query}";
            }
        }

        return $path;
    }


    public function setCurrentLocale( string | null $locale ) : void
    {
        $this->current = $locale ?? $this->locale;
    }


    public function getLastMatch() : int | null
    {
        return $this->match;
    }


    protected function getUrlSchema() : array
    {
        return $this->schema ??= $this->cache->load( self::CACHE_KEY, $this->createUrlSchema(...) );
    }


    private function createUrlSchema() : array
    {
        $schema = [];

        $items = $this->explorer->table('s_router')
            ->where('active = ?', 1 )
            ->where('code IS NOT NULL');

        foreach( $items as $item ) {
            $schema['c2r'][ $item->code ] = $item->id;
        }

        $items = $this->explorer->table('s_router_path')
            ->where('s_router.active = ?', 1 );

        foreach( $items as $item ) {
            if( $item->path === '') {
                continue;
            }

            $schema['ls2r'][ $item->lang ][ $item->path ] = $item->s_router_id;
            $schema['lr2s'][ $item->lang ][ $item->s_router_id ] = $item->path;
        }

        return $schema;
    }
}
