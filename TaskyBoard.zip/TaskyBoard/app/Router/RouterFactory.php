<?php declare(strict_types=1);

namespace App\Router;

use Nette\Application\Routers\RouteList;
use Nette\DI\Attributes\Inject;

class RouterFactory
{
    #[ Inject ]
    public StaticRouteFactory $routeFactory;

    private string $locale;

    private bool $debug;

    private array $defaults = [
            'action'    => 'default',
        ];

    public function __construct( string $locale, bool $debug = false )
    {
        $this->locale = $locale;
        $this->debug = $debug;
    }


    public function create() : RouteList
    {
        $action = '<presenter>/[<action>/][<id>]';

        $router = new RouteList;

        if( $this->debug ) {
            $router->withModule('Cron')
                ->addRoute('cron/<presenter>/');
        }

        $router->withModule('Api')
            ->addRoute('api/<presenter>/');

        $router->withModule('File')
            ->addRoute('file/<presenter>/<disk>/<name>[/<orig>]');

        $router->withModule('Admin')
            ->addRoute('admin/', ['presenter' => 'Home', 'locale' => $this->locale ] + $this->defaults )
            ->addRoute("admin/{$action}", ['locale' => $this->locale ] + $this->defaults );

        $router->add( $this->routeFactory->create() );


        return $router;
    }
}
