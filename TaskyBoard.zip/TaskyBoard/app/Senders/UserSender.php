<?php declare(strict_types=1);

namespace App\Senders;

use App\Dao\Model\User;
use App\Service\ResetPasswordTokenService;
use Nette\Bridges\ApplicationLatte\DefaultTemplate;
use Nette\Database\Table\ActiveRow;
use Nette\DI\Attributes\Inject;
use Nette\InvalidStateException;

class UserSender extends Sender
{
    #[ Inject ]
    public ResetPasswordTokenService $resetPasswordTokenService;

    public function forgotPassword( User $user, string $email = null ) : ActiveRow
    {
        $reset = $this->resetPasswordTokenService->createToken( $user->id );

        if( !$reset ) {
            throw new InvalidStateException("Does this fail?");
        }

        $link = $this->link('App:User:forgottenPassword', [
            'token' => $reset->token,
        ]);

        $template = $this->createTemplate('User/forgot-password');
        $template->email = $email;
        $template->link = $link;

        $this->sendToEmail( $template, $user, $email );

        return $reset;
    }


    protected function sendToEmail( DefaultTemplate $template, User $user, array | string | null $email ) : void
    {
        if( $user->deleted ) {
            return;
        } elseif( !$email ) {
            return;
        }

        if( is_string( $email )) {
            $email = [ $email ];
        }

        $this->setName( $template, $user );

        $message = $this->createMessage( $template );
        $message->setLocale( $this->getLocale( $user ));

        foreach( $email as $each ) {
            $message->addTo( $each );
        }

        $this->mailer->send( $message );
    }


    protected function sendToContact( DefaultTemplate $template, User $user ) : void
    {
        $this->sendToEmail( $template, $user, $user->getEmail() );
    }

    protected function getLocale( User $user ) : string
    {
        return $this->translator->getClientLocale( $user->preferred_language );
    }

    protected function setName( DefaultTemplate $template, User $user ) : void
    {
        $template->nick = $user->nick;
    }
}
