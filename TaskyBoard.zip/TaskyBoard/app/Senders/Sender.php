<?php declare(strict_types=1);

namespace App\Senders;

use App\Mailing\Messages\MessageFactory;
use App\Mailing\Messages\TemplateMessage;
use App\Templates\ContextFactory;
use App\Translation\NetteTranslator;
use Latte\Runtime\Filters;
use Nette\Application\LinkGenerator;
use Nette\Bridges\ApplicationLatte\DefaultTemplate;
use Nette\DI\Attributes\Inject;
use Nette\Http\Request;
use Nette\Mail\Mailer;

abstract class Sender
{
    protected ContextFactory
        $contextFactory;

    #[ Inject ]
    public MessageFactory
        $messageFactory;

    #[ Inject ]
    public LinkGenerator
        $linkGenerator;

    #[ Inject ]
    public NetteTranslator
        $translator;

    #[ Inject ]
    public Request
        $request;

    #[ Inject ]
    public Mailer
        $mailer;


    function injectContext( ContextFactory $contextFactory ) : void
    {
        $this->contextFactory = $contextFactory->withContext( __DIR__, '@email');
    }


    protected function createTemplate( string $view, string | false $layout = null ) : DefaultTemplate
    {
        $template = $this->contextFactory->createTemplate( $view, $layout );
        $template->openUrl = $this->request->getUrl();

        $template->getLatte()->addFilter('escapeHtmlAttr', Filters::escapeHtmlAttr(...));

        return $template;
    }


    protected function createMessage( DefaultTemplate $template ) : TemplateMessage
    {
        return $this->messageFactory->createMessage( $template );
    }


    protected function link( string $target, array $parameters = [] ) : string
    {
        $parameters['locale'] ??= $this->translator->getLocale();

        return $this->linkGenerator->link( $target, $parameters );
    }
}
