<?php

declare(strict_types=1);

namespace App\Interfaces;

interface IEnum
{
	public static function getNames() : array;

	public static function getName($key) : ?string;
}