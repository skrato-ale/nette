<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\User\Grids;

use App\Application\Aspects\WriteAware;
use App\Dao\UserDAO;
use App\Enums\PersonStatusEnum;
use App\Enums\UserStatusEnum;
use App\Modules\Base\Grids\DefineGrid;
use App\Service\UserService;
use Nette;
use Nette\Caching\Cache;
use Nette\Caching\Storage;
use Nette\Database\Table\ActiveRow;
use Nette\Database\Table\Selection;
use Nette\DI\Attributes\Inject;
use Nette\Utils\Html;

class UserGrid extends DefineGrid
{
    use WriteAware;

    private const DIV = ';';

    #[ Inject ]
    public UserDAO $userDAO;

    #[ Inject ]
    public UserService $userService;

    #[ Inject ]
    public Nette\Security\User $session;

    private Cache $cache;

    private array $store = [];

    public function __construct()
    {
        parent::__construct();

        $this->onSelect[] = $this->onSelect(...);
    }


    public function injectStorage( Storage $storage ) : void
    {
        $this->cache = new Cache( $storage, 'sto');
    }


    protected function createSelection() : Selection
    {
        $query = $this->userDAO->getTable()
            ->select('user.id, user.role_id, user.nick, user.phone, user.email, user.status, user.deleted, user.created, user.is_test_profile')
            ->group('user.id');

        return $query;
    }


    public function onStartup() : void
    {
        $prompt = $this->getPromptValue();

        $column = $this->addColumnText('id', 'ID')
            ->setSortable()
            ->setAlign('end')
            ->setTemplate( __DIR__ . '/templates/id.latte');

        $column->getElementPrototype('td')
            ->setAttribute('class', ['text-nowrap']);

        $column->setFilterText('user.id')
            ->setExactSearch();

        $this->addColumnText('nick', 'Nick')
            ->setTemplate( __DIR__ . '/templates/nick.latte', ['roles' => $roles ])
            ->setFilterText('user.nick');

        $this->addColumnText('email', 'E-mail')
            ->setTemplate( __DIR__ . '/templates/email.latte')
            ->setFilterText(['user.email', 'user.email_cc']);

        $this->addColumnText('phone', 'Telefon')
            ->setTemplate( __DIR__ . '/templates/phone.latte')
            ->setFilterText()
            ->setCondition( $this->createFilterPhone('user.phone'));

        $this->addColumnDateTime('created', 'Registrace')
            ->setSortable()
            ->setTemplate( __DIR__ . '/templates/created.latte')
            ->setFilterDateRange('user.created');

        $states = UserStatusEnum::getNames();

        $this->addColumnText('status', 'Stav uživatele')
            ->setTemplate(__DIR__ . '/templates/user-status.latte', [
                'states'        => $states,
                'userService'   => $this->userService,
            ])
            ->setFilterSelect( $states, 'user.status' );

        $this->addColumnText('shown', 'ZvK')
            ->setRenderer( $this->renderShown(...))
            ->getElementPrototype('td')
            ->setAttribute('class', ['text-nowrap']);

        $options = $this->getYesNoOptions();

        $this->addColumnText('is_test_profile', 'TP')
            ->setReplacement( $options )
            ->getElementPrototype('td')
            ->setAttribute('class', ['text-nowrap']);

        $this->addFilterSelect('is_test_profile', 'Testovací profil', $options )
            ->setPrompt( $prompt );

        if( $this->session->isAllowed('Admin:User', 'detail')) {
            $this->addActionPrimary('detail', 'Detail', ':Admin:Open:userProfile')
                ->setTemplate( __DIR__ . '/templates/action.latte');
        }

        $this->setColumnTips([
            'id'                => 'ID Uživatele /<br>ID Entity',
            'email'             => 'Registrační email /<br>Kontaktní email',
            'shown'             => 'Zobrazování v katalogu',
            'is_test_profile'   => 'Testovací profil',
        ], true );

        $this->setRowCallback( $this->onTableRow(...));
        
        $this->setOuterFilterRendering();
        $this->setDefaultSort(['id' => 'DESC']);
    }


    protected function onSelect( array $rows ) : void
    {
        if( !$rows ) {
            return;
        }

    }


    public function getContactAdmins( ActiveRow $row ) : array
    {
        $admins = $this->store['admin'][ $row->id ] ?? [];
        $users = [];

        foreach( $admins as $admin ) {
            if( isset( $this->store['user'][ $admin ] )) {
                $users[ $admin ] ??= $this->store['user'][ $admin ];
            }
        }

        ksort( $users );

        return $users;
    }


    public function getProfileID( ActiveRow $row ) : int | null
    {
        return $this->store['profile'][ $row->id ] ?? null;
    }


    protected function onTableRow( ActiveRow $row, Html $html )
    {
        if( $row->deleted ) {
            $html->setAttribute('class', 'table-danger');
        } elseif( $row->is_test_profile ) {
            $html->setAttribute('class', 'table-primary');
        }
    }


    protected function renderShown( ActiveRow $row ) : mixed
    {
        if( $row->entity_type === 'admin') {
            return null;
        }

        if( str_contains( $this->store['shown'], self::DIV . $row->id . self::DIV )) {
            return 'Ano';
        } else {
            return 'Ne';
        }
    }
}
