<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\User\Grids;

interface UserGridFactory
{
    public function create() : UserGrid;
}
