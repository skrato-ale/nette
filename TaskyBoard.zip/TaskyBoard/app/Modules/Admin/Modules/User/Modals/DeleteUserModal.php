<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\User\Modals;

use App\Application\Aspects\WriteAware;
use App\Dao\Model\User;
use App\Model\User\UserRow;
use App\Modules\Base\Forms\Form;
use App\Modules\Base\Forms\LayoutFormFactory;
use App\Service\UserService;
use App\AdminModule\Components\ModalControl;
use Nette\Bridges\ApplicationLatte\DefaultTemplate;
use Nette\DI\Attributes\Inject;

class DeleteUserModal extends ModalControl
{
    use WriteAware;

    #[Inject]
    public LayoutFormFactory $layoutFormFactory;

    #[Inject]
    public UserService $userService;

    protected User $user;

    protected User $coreUser;

    public function __construct( UserRow $user, User $coreUser )
    {
        parent::__construct();

        $this->user = User::from($user);
        $this->coreUser = $coreUser;
    }

    public function render() : void
    {
        /** @var DefaultTemplate $template */
        $template = $this->getTemplate();
        $template->user = $this->user;
        $template->render( __DIR__ . '/templates/delete-user.latte');
    }

    protected function createComponentForm() : Form
    {
        $form = $this->layoutFormFactory->create();
        $form->addTextArea('reason', 'Důvod')->setRequired('Důvod musí existovat');
        $form->addSubmit('send', 'Smazat');

        $form->onSuccess[] = $this->process(...);

        return $form;
    }

    public function process( Form $form, array $data ) : void
    {
        $this->tryCatchModal( function() use( $data ) {
            $this->userService->delete( $this->user, $data['reason'], true );
        });
    }
}
