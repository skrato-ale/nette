<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\User\Modals;

use App\Dao\Model\User;
use App\Model\User\UserRow;

interface DeleteUserModalFactory
{
    public function create( UserRow $user, User $coreUser ) : DeleteUserModal;
}