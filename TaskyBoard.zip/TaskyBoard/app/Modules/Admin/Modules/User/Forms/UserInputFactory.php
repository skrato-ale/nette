<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\User\Forms;

use App\Dao\UserDAO;
use App\Enums\CountryEnum;
use App\Enums\UserRoleEnum;
use App\Model\User\AdminUserManager;
use App\Model\User\UserRow;
use App\Modules\Base\Forms\Container;
use App\Modules\Base\Forms\Controls\DateInput;
use App\Modules\Base\Forms\Form;
use App\Service\UserService;
use App\Translation\NetteTranslator;
use Nette\Application\LinkGenerator;
use Nette\Database\Table\ActiveRow;
use Nette\DI\Attributes\Inject;
use Nette\Forms\Controls\SelectBox;
use Nette\Forms\Controls\TextInput;
use Nette\Utils\Strings;

class UserInputFactory
{
    #[ Inject ]
    public LinkGenerator
        $linkGenerator;

    #[ Inject ]
    public NetteTranslator
        $translator;

    #[ Inject ]
    public AdminUserManager
        $adminUserManager;

    #[ Inject ]
    public UserDAO
        $userDAO;

    protected string | null
        $phonePrefers = null;

    protected array
        $phoneLocales = ['cs' => 'cz'];

    protected array
        $frontRoles = [ UserRoleEnum::ROLE_PARTNER, UserRoleEnum::ROLE_CUSTOMER ];


    public function addAdminPersonSet( Form $form, ActiveRow | null $user, string $name = 'user') : Container
    {
        $form = $form->addContainer( $name );
        $this->addNick( $form, $user );

        if( !$user ) {
            $this->addPassword( $form );
        }

        $this->addEmail( $form, $user );
        $this->addPhone( $form );

        return $form;
    }


    public function addBirth( Form | Container $form, bool $require = true ) : DateInput
    {
        [ $max, $min ] = $this->adminUserManager->getBirthLimit();

        return $form->addCustomDate('birthdate', 'userPersonForm.birthDate')
            ->setRequired( $require ? 'form.birthday.please_this_field_was_required' : false )
            ->setHtmlType('text')
            ->addRule( DateInput::LTE, $error = 'form.user.registrationStep1.validationError.birthday_is_not_valid', $max->format('Y-m-d'))
            ->addRule( DateInput::GTE, $error, $min->format('Y-m-d'));
    }


    public function addPassword( Form | Container $form ) : array
    {
        $first = $form->addPassword('password', 'form.user.registrationStep1.password')
            ->setRequired();

        $second = $form->addPassword('password2', 'form.user.registrationStep1.password2')
            ->setRequired('verification_required');

        $second->addConditionOn( $first, Form::Filled )
            ->addRule( Form::Equal, 'form.user.registrationStep1.validationError.passwordMismatch', $first );

        return [ $first, $second ];
    }


    public function addNick( Form | Container $form, ActiveRow $user = null, bool $require = true, bool $unique = true ) : TextInput
    {
        $input = $form->addText('nick', 'form.user.registrationStep1.nick')
            ->setRequired( $require ? 'form.user.registrationStep1.validationError.nickRequired' : false )
            ->setNullable();

        $input->addCondition( Form::Filled )
            ->addFilter( $this->fixNick(...));

        $input->addRule( Form::MinLength, null, $this->adminUserManager->lengths['nick'][0] );

        $input->addCondition( Form::MinLength, $limit = $this->adminUserManager->lengths['nick'][1] )
            ->addRule( Form::MaxLength, 'form.user.registrationStep1.validationError.length', $limit );

        $input->addRule( Form::Pattern, 'form.user.registrationStep1.validationError.nickFormat', $this->adminUserManager->patterns['nick'] );

        if( $unique ) {
            $input->addCondition( Form::Filled )
                ->addRule( $this->isNickUnique(...), $message = 'nickAlreadyExist', $user );

            Form::setApiValidator( $input, $message, $this->linkGenerator->link('App:Validate:nick', ['exist' => $user?->id ] ));
        }

        return $input;
    }


    public function addEmail( Form | Container $form, ActiveRow $user = null, bool $require = true, bool $unique = true ) : TextInput
    {
        $input = $form->addText('email', 'form.email.registration')
            ->setRequired( $require ? 'form.user.registrationStep1.validationError.emailRequired' : false )
            ->setNullable();

        $input->addCondition( Form::MinLength, $limit = $this->emailManager->lengths['email'] )
            ->addRule( Form::MaxLength, null, $limit );

        $input->addRule( Form::Email );

        if( $unique ) {
            $input->addCondition( Form::Filled )
                ->addRule( $this->isEmailUnique(...), $message = 'registration.emailAlreadyExist', $user );

            Form::setApiValidator( $input, $message, $this->linkGenerator->link('App:Validate:email', ['exist' => $user?->id ] ));
        }

        return $input;
    }


    public function addPhone( Form | Container $form, bool $require = false ) : TextInput
    {
        $input = $form->addText('phone', 'form.user.registrationStep1.phone')
            ->setRequired( $require )
            ->setNullable();

        $input->addCondition( Form::Filled )
            ->addFilter( $this->fixPhone(...));

        $input->addCondition( Form::MinLength, $limit = $this->phoneManager->lengths['phone'] )
            ->addRule( Form::MaxLength, null, $limit );

        $input->addRule( $this->isPhoneValid(...), 'form.error.phone.wrongFormat');

        $this->setPhoneHelper( $input );

        return $input;
    }


    public function setPhoneHelper( TextInput $input ) : void
    {
        $input->setHtmlAttribute('data-phone-input', $this->getPhoneLocale() );
        $input->setHtmlAttribute('data-phone-prefer', $this->getPhonePreference() );
    }


    public function addPrefCountry( Form | Container $form, bool $require = true ) : SelectBox
    {
        return $form->addSelect('preferred_country_id', 'form.user.registrationStep1.preferredCountry', CountryEnum::getNames() )
            ->setPrompt('choose')
            ->setRequired( $require );
    }


    public function getPhoneLocale() : string
    {
        $locale = $this->translator->getLocale();

        return $this->phoneLocales[ $locale ] ?? $locale;
    }


    public function getPhonePreference() : string
    {
        if( $this->phonePrefers === null ) {
            $locales = $this->translator->getVisibleLocales();

            array_walk( $locales, function( string &$locale )  {
                $locale = $this->phoneLocales[ $locale ] ?? $locale;
            });

            $this->phonePrefers = implode(',', $locales );
        }

        return $this->phonePrefers;
    }


    protected function fixPhone( mixed $value ) : mixed
    {
        if( is_string( $value )) {
            $value = Strings::replace( $value, '~\s+~');
        }

        return $value;
    }


    protected function fixNick( mixed $value ) : mixed
    {
        if( is_string( $value )) {
            $value = UserService::sanitizeNick( $value );
        }

        return $value;
    }


    protected function isNickUnique( TextInput $input, UserRow | null $exist ) : bool
    {
        return $this->adminUserManager->isNickUnique( $input->getValue(), $exist );
    }


    protected function isEmailUnique( TextInput $input, UserRow | null $exist )
    {
        return $this->adminUserManager->isEmailUnique( $input->getValue(), $exist );
    }
}
