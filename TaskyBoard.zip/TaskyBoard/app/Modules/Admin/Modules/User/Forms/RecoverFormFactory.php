<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\User\Forms;

use App\Dao\Model\User;

interface RecoverFormFactory
{
    function create( User $user ) : RecoverForm;
}
