<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\User\Forms;

use App\Dao\Model\User;
use App\Modules\Base\Forms\DefineForm;
use App\Modules\Base\Forms\LayoutForm;
use App\Senders\UserSender;
use Nette\DI\Attributes\Inject;
use Nette\Utils\Arrays;
use Throwable;

class RecoverForm extends DefineForm
{
    #[ Inject ]
    public UserSender
        $userSender;


    protected User
        $user;

    protected array
        $options;


    public function __construct( User $user )
    {
        parent::__construct();

        $this->user = $user;

        $this->onDefault[] = $this->onDefault(...);
        $this->onSuccess[] = $this->onSuccess(...);
    }


    public function onStartup() : void
    {
        $this->options = array_filter([
            $this->user->email,
            $this->user->email_cc,
        ]);

        $this->addRadioList('email', 'E-mail', $this->options ?: ['No email'])
            ->setRequired();

        $this->addSubmit('btn', 'Odeslat');

        if( !$this->options ) {
            $this->setDisabled();
        }
    }


    protected function onDefault() : array
    {
        return [
            'email' => array_key_first( $this->options ),
        ];
    }


    protected function onSuccess( LayoutForm $form, array $post ) : void
    {
        try {
            $this->userSender->forgotPassword( $this->user, $this->options[ $post['email']] );
        } catch( Throwable $error ) {
            $this->addError( $error );

            return;
        }

        Arrays::invoke( $this->onFinish );
    }
}
