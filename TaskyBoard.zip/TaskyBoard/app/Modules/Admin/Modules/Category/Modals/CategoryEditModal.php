<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Category\Modals;

use App\Application\Aspects\WriteAware;
use App\Application\Events\Anchor;
use App\Dao\CategoryDAO;
use App\Modules\Base\Forms\Form;
use App\Modules\Base\Forms\LayoutFormFactory;
use App\Service\FormsInputService;
use App\AdminModule\Components\ModalControl;
use App\Model\Category\CategoryRow;
use Nette\Application\Attributes\Persistent;
use Nette\Database\Table\ActiveRow;
use Nette\DI\Attributes\Inject;

class CategoryEditModal extends ModalControl implements Anchor
{
    use WriteAware;

    #[Inject]
    public LayoutFormFactory $layoutFormFactory;

    #[Inject]
    public CategoryDAO $categoryDAO;

    protected ?ActiveRow $category = null;

    #[ Persistent ]
    public ?int $categoryId = null;

    public function __construct(?ActiveRow $category = null)
    {
        parent::__construct();
    }

    public function onAnchor(): void
    {
        if( $this->categoryId ) {
            $this->category = $this->categoryDAO->find($this->categoryId);
        }
    }

    public function render(): void
    {
        /** @var DefaultTemplate $template */
        $template = $this->getTemplate();
        $template->categoryId =  $this->categoryId;
        $template->render(__DIR__ . '/templates/categoryEditModal.latte');
    }

    protected function createComponentForm(): Form
    {
        $form = $this->layoutFormFactory->create();
        $this->addFormFields($form);

        if ($this->category) {
            $form->setDefaults($this->category->toArray());
        } else {
            $form->setDefaults([
                'parent' => CategoryRow::ID_ROOT,
            ]);
        }

        $form->onSuccess[] = [$this, 'process'];
        return $form;
    }

    private function addFormFields(Form $form): void
    {
        $form->addText('name', 'Název');
        $form->addText('translation_key', 'Překladový klíč');
        $form->addHidden('id', 'cat_id');
        $form->addTextArea('note', 'Popis');
        $form->addInteger('ord', 'Pořadí')->addRule(...FormsInputService::$intRule);
        $form->addSubmit('submit', 'Uložit');
    }

    public function process(Form $form, array $data): void
    {
        $this->tryCatchModal(function() use ($data) {

        });
    }

}
