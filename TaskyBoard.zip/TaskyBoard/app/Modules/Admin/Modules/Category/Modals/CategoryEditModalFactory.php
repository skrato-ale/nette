<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Category\Modals;

use Nette\Database\Table\ActiveRow;

interface CategoryEditModalFactory
{
    public function create( ActiveRow $category = null ) : CategoryEditModal;
}