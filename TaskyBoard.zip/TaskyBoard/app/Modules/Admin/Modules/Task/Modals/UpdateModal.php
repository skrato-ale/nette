<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modals;

use App\Application\Aspects\WriteAware;
use App\Application\Events\Anchor;
use App\Dao\TaskDAO;
use App\Model\Task\TaskRow;
use App\Modules\Base\Forms\LayoutForm;
use Nette\Application\Attributes\Persistent;
use Nette\Database\Explorer;
use Nette\DI\Attributes\Inject;

class UpdateModal extends TaskModal implements Anchor
{
    use WriteAware;


    protected Explorer
        $explorer;

    #[ Inject ]
    public TaskDAO
        $taskDAO;


    #[ Persistent ]
    public int | null
        $task = null;


    protected TaskRow
        $taskRow;


    public function injectExplorer( Explorer $explorer ) : void
    {
        $this->explorer = $explorer;
    }


    public function render() : void
    {
        $template = $this->getTemplate();
        $template->task = $this->taskRow;

        $template->render( __DIR__ . '/templates/update.latte');
    }


    public function onAnchor() : void
    {
        $task = $this->taskDAO->find( $this->task ?? $this->error() );

        $this->taskRow = $task ?? $this->error();
    }


    protected function onDefaultTask() : array | null
    {
        $data = $this->taskRow->toArray();
        $data['start_time'] = $this->taskRow->start_date;

        return $data;
    }


    protected function onDefaultNote() : array | null
    {
        return $this->taskRow->toArray();
    }


    protected function onSuccessTask( LayoutForm $form, array $post ) : void
    {
        $this->tryCatchModal( function() use( $post ) {
            $userRow = $this->taskInputFactory->getAssignedRow( $post );

            $this->taskManager->update( $this->taskRow, $userRow, $post );
        });
    }


    protected function onSuccessNote( LayoutForm $form, array $post ) : void
    {
        $this->tryCatchModal( function() use( $post ) {
            $this->noteManager->update( $this->taskRow, $post );
        });
    }

}
