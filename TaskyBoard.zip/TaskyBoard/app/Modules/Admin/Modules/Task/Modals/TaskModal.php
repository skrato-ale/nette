<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modals;

use App\Dao\UserDAO;
use App\Model\Task\NoteManager;
use App\Model\Task\TaskManager;
use App\Modules\Admin\Modules\Task\Forms\NoteInputFactory;
use App\Modules\Admin\Modules\Task\Forms\TaskInputFactory;
use App\Modules\Base\Forms\LayoutForm;
use App\Modules\Base\Forms\LayoutFormFactory;
use App\AdminModule\Components\ModalControl;
use Nette\DI\Attributes\Inject;

abstract class TaskModal extends ModalControl
{
    #[ Inject ]
    public LayoutFormFactory
        $layoutFormFactory;

    #[ Inject ]
    public TaskInputFactory
        $taskInputFactory;

    #[ Inject ]
    public NoteInputFactory
        $noteInputFactory;


    #[ Inject ]
    public TaskManager
        $taskManager;

    #[ Inject ]
    public NoteManager
        $noteManager;

    #[ Inject ]
    public UserDAO
        $userDAO;


    private function createTaskForm() : LayoutForm
    {
        $form = $this->layoutFormFactory->create();

        return $form;
    }


    protected function createComponentTask() : LayoutForm
    {
        $form = $this->createTaskForm();

        $this->taskInputFactory->addCreateSet( $form, $this->isUpdate() );

        $this->addSubmit( $form );

        $form->onDefault[] = $this->onDefaultTask(...);
        $form->onSuccess[] = $this->onSuccessTask(...);

        return $form;
    }


    protected function createComponentNote() : LayoutForm
    {
        $form = $this->createTaskForm();

        $this->noteInputFactory->addCreateSet( $form );

        $this->addSubmit( $form );

        $form->onDefault[] = $this->onDefaultNote(...);
        $form->onSuccess[] = $this->onSuccessNote(...);

        return $form;
    }


    private function addSubmit( LayoutForm $form ) : void
    {
        $form->addSubmit('send', $this->isUpdate() ? 'Uložit' : 'Vytvořit');
    }


    protected function isUpdate() : bool
    {
        return $this instanceof UpdateModal;
    }


    abstract protected function onDefaultTask() : array | null;

    abstract protected function onDefaultNote() : array | null;

    abstract protected function onSuccessTask( LayoutForm $form, array $post ) : void;

    abstract protected function onSuccessNote( LayoutForm $form, array $post ) : void;
}