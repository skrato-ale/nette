<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modals;

use App\Application\Aspects\WriteAware;
use App\Application\Events\Anchor;
use App\Model\Task\TaskRow;
use App\Model\User\UserRow;
use App\Modules\Base\Forms\LayoutForm;
use Nette\Application\Attributes\Persistent;
use Nette\DI\Attributes\Inject;
use Nette\Security\User;

class CreateModal extends TaskModal implements Anchor
{
    use WriteAware;

    #[ Inject ]
    public User $session;

    #[ Persistent ]
    public int | null $user = null;

    #[ Persistent ]
    public int | null $email = null;

    #[ Persistent ]
    public int | null $phone = null;

    #[ Persistent ]
    public int $note = 1;

    protected  UserRow | null $entityRow;

    protected UserRow $targetRow;

    public function __construct( UserRow $entity = null )
    {
        parent::__construct();

        $this->entityRow = $entity;
    }


    public function render() : void
    {
        $template = $this->getTemplate();
        $template->target = $this->targetRow;

        $template->render( __DIR__ . '/templates/create.latte');
    }


    public function onAnchor() : void
    {
        if( $this->entityRow ) {
            $target = $this->entityRow;
        } elseif( $this->user ) {
            $target = $this->userDAO->find( $this->user );
        } else {
            $this->error();
        }

        if( !$target ) {
            $this->error();
        }

        $this->targetRow = $target;
    }


    protected function onDefaultTask() : array | null
    {
        $logged = $this->session->getId();
        $select = $this->taskInputFactory->getAssignedList();

        $start = $this->taskManager->getTaskStart();

        return [
            'assigned_to_id' => isset( $logged, $select[ $logged ] ) ? $logged : null,
            'start_date'    => $start,
            'start_time'    => $start,
            'priority'      => TaskRow::PRIORITY_LOW,
        ];
    }


    protected function onDefaultNote() : array | null
    {
        return [
            'priority'      => TaskRow::PRIORITY_LOW,
        ];
    }


    protected function onSuccessTask( LayoutForm $form, array $post ) : void
    {
        $this->tryCatchModal( function() use( $post ) {
            $userRow = $this->taskInputFactory->getAssignedRow( $post );

            $this->taskManager->create( $this->targetRow, $userRow, $post );
        });
    }


    protected function onSuccessNote( LayoutForm $form, array $post ) : void
    {
        $this->tryCatchModal( function() use( $post ) {
            $this->noteManager->create( $this->targetRow, $post );
        });
    }
}
