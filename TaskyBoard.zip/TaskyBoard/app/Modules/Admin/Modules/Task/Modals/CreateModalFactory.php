<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modals;


use App\Model\User\UserRow;

interface CreateModalFactory
{
    function create( UserRow $entity = null ) : CreateModal;
}