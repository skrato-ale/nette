<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Forms;

use App\Dao\UserDAO;
use App\Enums\TaskStateEnum;
use App\Enums\TaskTypeEnum;
use App\Model\Task\TaskManager;
use App\Model\Task\TaskRow;
use App\Model\User\UserRow;
use App\Modules\Base\Forms\Container;
use App\Modules\Base\Forms\Controls\DateInput;
use App\Modules\Base\Forms\Controls\TimeInput;
use App\Modules\Base\Forms\Form;
use Nette\DI\Attributes\Inject;
use Nette\Forms\Controls\SelectBox;
use Nette\Forms\Controls\TextArea;
use Nette\Forms\Controls\TextInput;
use Nette\InvalidStateException;

class TaskInputFactory
{
    #[ Inject ]
    public TaskManager
        $taskManager;

    #[ Inject ]
    public UserDAO
        $userDAO;


    private array | null
        $assignUserRows = null;


    public function addCreateSet( Form $form, bool $update, string $name = null ) : Form | Container
    {
        if( $name ) {
            $form = $form->addContainer( $name );
        }

        $this->addName( $form );
        $this->addDescription( $form );
        $this->addPriority( $form );
        $this->addAssignedTo( $form );

        if( $update ) {
            $this->addStatus( $form );
        }

        $this->addContactType( $form );
        $this->addNextContactType( $form );
        $this->addStartDate( $form );
        $this->addStartTime( $form );

        return $form;
    }


    public function addCommentSet( Form $form, string $name = 'task') : Container
    {
        $form = $form->addContainer( $name );

        $this->addStartDate( $form );
        $this->addStartTime( $form );
        $this->addNextContactType( $form );
        $this->addAssignedTo( $form );
        $this->addStatus( $form );

        return $form;
    }


    public function addBulkSet( Form $form, string $name = 'task') : Container
    {
        $form = $form->addContainer( $name );

        $this->addAssignedTo( $form, false )
            ->setPrompt('Beze změny');

        $this->addStatus( $form, false )
            ->setPrompt('Beze změny');

        $this->addPriority( $form, false )
            ->setPrompt('Beze změny');

        $this->addStartDate( $form, false );
        $this->addStartTime( $form, false );

        return $form;
    }


    public function addName( Form | Container $form ) : TextInput
    {
        return $form->addText('name', 'Název úkolu')
            ->setRequired('Vyplňte název úkolu')
            ->addRule( $form::MaxLength, null, $this->taskManager->lengths['name'] );
    }


    public function addDescription( Form | Container $form ) : TextArea
    {
        return $form->addTextArea('description', 'Text úkolu', rows: 4 )
            ->setHtmlAttribute('class', 'js-redactor')
            ->setRequired('Vyplňte text úkolu')
            ->addRule( $form::MaxLength, null, $this->taskManager->lengths['description'] );
    }


    public function addContactType( Form | Container $form ) : SelectBox
    {
        return $form->addSelect('contact_type', 'Způsob kontaktu', TaskTypeEnum::getNames() )
            ->setPrompt('--- vyberte ---')
            ->setRequired('Zadejte způsob kontaktu');
    }


    public function addStartDate( Form | Container $form, bool $require = true ) : DateInput
    {
        $input = $form->addCustomDate('start_date', 'Datum následného úkolu')
            ->setRequired( $require ? 'Zadejte datum' : false );

        return $input;
    }


    public function addStartTime( Form | Container $form, bool $require = true ) : TimeInput
    {
        $input = $form->addCustomTime('start_time', 'Čas úkolu')
            ->setRequired( $require ? 'Zadejte čas' : false );
            
        return $input;
    }


    public function addNextContactType( Form | Container $form ) : SelectBox
    {
        return $form->addSelect('next_contact_type', 'Následujcí způsob kontaktu', TaskTypeEnum::getNamesNextContact() )
            ->setPrompt('--- vyberte ---')
            ->setRequired('Vyberte následujcí způsob kontaktu');
    }


    public function addAssignedTo( Form | Container $form, bool $require = true ): SelectBox
    {
        $options = $this->userDAO->listAdmins(cache: $this->assignUserRows);

        $select = $form->addSelect('assigned_to_id', 'Přiřazeno', $options )
            ->setRequired( $require ? 'Zadejte uživatele k úkolu' : false )
            ->setPrompt('---vyberte---');

        return $select;
    }


    public function getAssignedList() : array
    {
        return $this->assignUserRows ?? throw new InvalidStateException("No list.");
    }


    public function getAssignedRow( array $values ) : UserRow | false
    {
        if( isset( $values['assigned_to_id'] )) {
            return $this->assignUserRows[ $values['assigned_to_id'] ] ?? throw new InvalidStateException("No user.");
        } else {
            return false;
        }
    }


    public function addStatus( Form | Container $form, bool $require = true ) : SelectBox
    {
        return $form->addSelect('task_state', 'Stav úkolu', TaskStateEnum::getNames() )
            ->setRequired( $require ? 'Zadejte stav úkolu' : false );
    }


    public function addPriority( Form | Container $form, bool $require = true ) : SelectBox
    {
        return $form->addSelect('priority', 'Priorita', TaskRow::getPriorityNames() )
            ->setRequired( $require );
    }

}
