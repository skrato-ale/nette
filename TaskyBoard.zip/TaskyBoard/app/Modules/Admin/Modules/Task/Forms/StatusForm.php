<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Forms;

use App\Application\Aspects\WriteAware;
use App\Model\Task\TaskManager;
use App\Model\Task\TaskRow;
use App\Modules\Base\Forms\DefineForm;
use Nette\DI\Attributes\Inject;

class StatusForm extends DefineForm
{
    use WriteAware;

    #[ Inject ]
    public TaskInputFactory $taskInputFactory;

    #[ Inject ]
    public TaskManager $taskManager;

    protected TaskRow $taskRow;

    public function __construct( TaskRow $task )
    {
        parent::__construct();

        $this->taskRow = $task;

        $this->onSuccess[] = $this->onSuccess(...);
        $this->onDefault[] = $this->onDefault(...);

    }


    public function onStartup() : void
    {
        $this->taskInputFactory->addStatus( $this );

        $this->addSubmit('send', 'Uložit');
    }


    public function onSuccess( self $form, array $post ) : void
    {
        $this->tryCatchForm( function() use( $post ) {
            $this->taskManager->update( $this->taskRow, $post );
        });
    }


    public function onDefault() : array | null
    {
        return $this->taskRow->toArray();
    }
}