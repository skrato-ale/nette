<?php declare( strict_types=1 );

namespace App\Modules\Admin\Modules\Task\Forms;

use App\Model\Task\TaskRow;

interface StatusFormFactory
{
    function create( TaskRow $task ) : StatusForm;
}