<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Forms;

use App\Enums\TaskTypeEnum;
use App\Model\Task\NoteManager;
use App\Model\Task\TaskRow;
use App\Modules\Base\Forms\Container;
use App\Modules\Base\Forms\Form;
use Nette\DI\Attributes\Inject;
use Nette\Forms\Controls\SelectBox;
use Nette\Forms\Controls\TextArea;
use Nette\Forms\Controls\TextInput;

class NoteInputFactory
{
    #[ Inject ]
    public NoteManager
        $noteManager;


    public function addCreateSet( Form $form, string $name = null ) : Form | Container
    {
        if( $name ) {
            $form = $form->addContainer( $name );
        }

        $this->addName( $form );
        $this->addDescription( $form );
        $this->addContactType( $form );
        $this->addPriority( $form );

        return $form;
    }


    public function addName( Form | Container $form ) : TextInput
    {
        return $form->addText('name', 'Název poznámky')
            ->setRequired( false )
            ->addRule( $form::MaxLength, null, $this->noteManager->lengths['name'] );
    }


    public function addDescription( Form | Container $form ) : TextArea
    {
        return $form->addTextArea('description', 'Text poznámky', rows: 4 )
            ->setHtmlAttribute('class', 'js-redactor')
            ->setRequired('Vyplňte text poznámky')
            ->addRule( $form::MaxLength, null, $this->noteManager->lengths['description'] );
    }


    public function addContactType( Form | Container $form ) : SelectBox
    {
        return $form->addSelect('contact_type', 'Způsob kontaktu', TaskTypeEnum::getNames() )
            ->setPrompt('--- vyberte ---')
            ->setRequired('Zadejte způsob kontaktu');
    }


    public function addPriority( Form | Container $form ) : SelectBox
    {
        return $form->addSelect('priority', 'Priorita', TaskRow::getPriorityNames() )
            ->setRequired();
    }
}
