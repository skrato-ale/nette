<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Grids;

use App\Application\Aspects\WriteAware;
use App\Application\Events\Anchor;
use App\Dao\Model\User;
use App\Dao\TaskDAO;
use App\Dao\UserDAO;
use App\Enums\TaskSelectTypeEnum;
use App\Enums\TaskStateEnum;
use App\Enums\TaskTypeEnum;
use App\Model\Task\TaskManager;
use App\Model\Task\TaskRow;
use App\Modules\Admin\Modules\Task;
use App\Modules\Base\Grids\DefineGrid;
use Nette;
use Nette\Database\Table\ActiveRow;
use Nette\Database\Table\Selection;
use Nette\DI\Attributes\Inject;
use Nette\Utils\DateTime;
use Nette\Utils\Html;
use Nette\Utils\Strings;

class TaskGrid extends DefineGrid implements Anchor
{
    use WriteAware;


    #[ Inject ]
    public Task\Modules\Comment\Modals\CreateModalFactory
        $commentModalFactory;

    #[ Inject ]
    public Task\Modals\AssignModalFactory
        $assignModalFactory;

    #[ Inject ]
    public Task\Modals\UpdateModalFactory
        $updateModalFactory;

    #[ Inject ]
    public Task\Modules\Comment\Modals\BulkCommentModalFactory
        $bulkCommentModalFactory;

    #[ Inject ]
    public TaskManager
        $taskManager;

    #[ Inject ]
    public TaskDAO
        $taskDAO;
    
    #[ Inject ]
    public UserDAO
        $userDAO;

    #[ Inject ]
    public Nette\Security\User
        $session;


    private User | null
        $user = null;

    private bool
        $userGlobal;

    private bool
        $userMarket;

    private bool
        $userAssign;

    private array
        $phones = [];

    private array
        $emails = [];

    public bool
        $profileView = false;

    public function __construct()
    {
        parent::__construct();

        $this->onSelect[] = $this->onSelect(...);
    }

    public function onAnchor(): void
    {
        $presenter = $this->getPresenter();
        $this->profileView = $presenter instanceof ProfilePresenter;
    }


    function setFromUser( User $user, bool $global = false, bool $market = false, bool $assign = false ) : void
    {
        $this->user = $user;
        $this->userGlobal = $global;
        $this->userMarket = $market;
        $this->userAssign = $assign;
    }

    protected function createSelection() : Selection
    {
        $scope = [];

        if( $this->user ) {
            if( $this->userAssign ) {
                $scope['task.assigned_to_id'] = $this->user->id;
            } elseif( $this->userGlobal ) {
                $scope['task.created_by_id'] =
                $scope['task.assigned_to_id'] =
                $scope['task.task_to_user_id'] = $this->user->id;
            } else {
                $scope['task.created_by_id'] =
                $scope['task.task_to_user_id'] = $this->user->id;
            }
        }

        $query = $this->taskDAO->getTable();

        if( $scope ) {
            $query->whereOr( $scope );
        } elseif( $this->user ) {
            $query->where('0');
        }

        return $query;
    }


    public function onStartup() : void
    {
        $states = TaskStateEnum::getNames();
        $colors = [
            TaskStateEnum::NEW          => 'danger',
            TaskStateEnum::UNFINISHED   => 'warning',
            TaskStateEnum::DONE         => 'success',
        ];

        $icons = [
            TaskStateEnum::NEW          => 'far fa-hourglass',
            TaskStateEnum::UNFINISHED   => 'far fa-user',
            TaskStateEnum::DONE         => 'far fa-square-check',
        ];

        $this->addColumnText('icon', 'Stav')
            ->setTemplate( __DIR__ . '/templates/icon.latte', ['states' => $states, 'colors' => $colors, 'icons' => $icons ])
            ->setAlign('center');

        $this->addColumnText('id','ID úkolu')
            ->setSortable()
            ->setFilterText('task.id')
            ->setExactSearch();

        $selectTypes = TaskSelectTypeEnum::getNames();
        $contactTypes = TaskTypeEnum::getNames();

        if( false ) {
            $this->addColumnText('task_select_type', 'Poznámka / Úkol')
                ->setReplacement( $selectTypes )
                ->setFilterSelect( $selectTypes )
                ->setPrompt( $this->getPromptValue() );
        } else {
            $this->addColumnText('type', 'Typ / Způsob kontaktu')
                ->setTemplate( __DIR__ . '/templates/type.latte', ['selectTypes' => $selectTypes, 'contactTypes' => $contactTypes ]);

            $this->addFilterSelect('task_select_type', 'Typ', $selectTypes )
                ->setPrompt( $this->getPromptValue() );

            $this->addFilterSelect('contact_type','Způsob kontaktu', $contactTypes )
                ->setPrompt( $this->getPromptValue() );

            $this->addFilterSelect('task_state','Stav úkolu', $states )
                ->setPrompt( $this->getPromptValue() );
        }

        $options = [
            'user'  => 'User',
            'phone' => 'Telefon',
            'email' => 'Email',
        ];

        if( false ) {
            $columns = [
                'user'  => 'task_to_user_id'
            ];

            $this->addColumnText('from_type', 'Typ vazby')
                ->setTemplate( __DIR__ . '/templates/from-type.latte', ['options' => $options, 'columns' => $columns ])
                ->setFilterSelect( $options )
                ->setPrompt( $this->getPromptValue() )
                ->setCondition( $this->filterFromType(...));
        } else {
            $this->addFilterSelect('from_type', 'Typ vazby', $options )
                ->setPrompt( $this->getPromptValue() )
                ->setCondition( $this->filterFromType(...));
        }

        $this->addColumnText('from', 'Záznam vazby')
            ->setTemplate(__DIR__ . '/templates/from-value.latte', ['options' => $options ])
            ->setFilterText()
            ->setPlaceholder('Zadejte celý nick / telefon / email')
            ->setCondition( $this->filterFromValue(...));

        $admins = $this->userDAO->listAdmins();

        if( false ) {
            $this->addColumnText('created_by_id','Vytvořeno uživatelem')
                ->setTemplate(__DIR__ . '/templates/createdBy.latte')
                ->setReplacement( $admins )
                ->setFilterSelect( $admins )
                ->setPrompt( $this->getPromptValue() );

            $this->addColumnText('assigned_to_id','Úkol přiřazen')
                ->setTemplate(__DIR__ . '/templates/assignedTo.latte')
                ->setReplacement( $admins )
                ->setFilterSelect( $admins )
                ->setPrompt( $this->getPromptValue() );
        } else {
            $this->addColumnText('user','Vytvořeno / Přiřazeno')
                ->setTemplate( __DIR__ . '/templates/user.latte')
                ->setAlign('center');

            $this->addFilterSelect('created_by_id','Vytvořeno uživatelem', $admins )
                ->setPrompt( $this->getPromptValue() );

            $this->addFilterSelect('assigned_to_id','Přiřazeno uživateli', $admins )
                ->setPrompt( $this->getPromptValue() );
        }

        if( false ) {
            $this->addColumnText('name','Název úkolu')
                ->setFilterText();
        } else {
            $this->addFilterText('name', 'Název úkolu');
        }

        $this->addColumnText('description', 'Název / Text', 'description')
            ->setTemplate( __DIR__ . '/templates/description.latte');

        $this->addFilterText('description', 'Text úkolu');

        if( false ) {
            $this->addColumnText('contact_type','Způsob kontaktu')
                ->setReplacement( $contactTypes )
                ->setFilterSelect( $contactTypes )
                ->setPrompt( $this->getPromptValue() );
        }

        $taskNextContactTypes = TaskTypeEnum::getNamesNextContact();

        $this->addColumnText('next_contact_type','Následujcí způsob kontaktu')
            ->setReplacement( $taskNextContactTypes )
            ->setFilterSelect( $taskNextContactTypes )
            ->setPrompt( $this->getPromptValue() );

        $today = new DateTime;

        $this->addColumnDateTime('start_date','Datum nasledného úkolu')
            ->setTemplate( __DIR__ . '/templates/expected.latte', ['today' => $today ])
            ->setSortable()
            ->setSortableCallback( $this->createSorterFilled('start_date'))
            ->setFilterDateRange();

        $this->addColumnDateTime('created','Vytvořeno dne')
            ->setTemplate( __DIR__ . '/templates/created.latte')
            ->setSortable()
            ->setFilterDateRange();

        $this->addAction('action', '')
            ->setTemplate( __DIR__ . '/templates/action.latte');

        $this->addGroupButtonAction('Předat úkol')
            ->onClick[] = $this->handleAssign(...);

        $this->addGroupButtonAction('Hromadná poznámka')
            ->onClick[] = $this->handleBulkComment(...);


        $this->setRowCallback( $this->listenRow(...));
        $this->setDefaultSort(['id' => 'DESC']);
        $this->setOuterFilterRendering();
    }


    public function onSelect( array $rows ) : void
    {        
        if( !$rows ) {
            return;
        }
    }


    protected function filterFromType( Selection $query, string $value ) : void
    {
        if ( $value === 'user') {
            $query->where('task_to_user_id IS NOT NULL');
        } else {
            $query->where('0');
        }
    }


    protected function filterFromValue( Selection $query, string $value ) : void
    {
        $value = Strings::trim( $value );

        $object = $this->userDAO->findByNick( $value );
        $column = 'task_to_user_id';

        if( $object ) {
            $query->where("{$column} = ?", $object->id );
        } else {
            $query->where('0');
        }
    }


    public function handleStatus( int $id, int $status ) : void
    {
        $task = $this->taskManager->find( $id );

        if( $task and $task->isTask() ) {
            $this->tryCatchCtrl( function() use( $task, $status ) {
                $this->taskManager->updateStatus( $task, $status );
            });
        }

        $this->autoScroll = false;

        $this->redrawItem( $id, 'task.id');
    }


    public function handleUpdate( string $id ) : void
    {
        $this->getPresenter()->initModal( $this, 'update', ['task' => $id ]);
    }


    public function handleComment( string $id ) : void
    {
        $this->getPresenter()->initModal( $this, 'comment', ['task' => $id ]);
    }


    public function handleAssign( array $ids ) : void
    {
        $this->abortFilter = true;

        if( !$ids ) {
            return;
        }

        $ids = implode( Task\Modals\AssignModal::DIVIDER, $ids );

        $this->getPresenter()->initModal( $this, 'assign', ['task' => $ids ]);
    }


    public function handleBulkComment( array $ids ) : void
    {
        $this->abortFilter = true;

        if( !$ids ) {
            return;
        }

        $ids = implode( Task\Modules\Comment\Modals\BulkCommentModal::DIVIDER, $ids );

        $this->getPresenter()->initModal( $this, 'bulkCommentAssign', ['task' => $ids ]);
    }


    protected function createComponentAssign() : Task\Modals\AssignModal
    {
        $modal = $this->assignModalFactory->create();
        $modal->onFinish[] = function() {
            $this->reloadTheWholeGrid();

            $this->payload->scroll = false;
        };

        return $modal;
    }


    protected function createComponentUpdate() : Task\Modals\UpdateModal
    {
        $modal = $this->updateModalFactory->create();
        $modal->onFinish[] = function() {
            $this->reloadTheWholeGrid();

            $this->payload->scroll = false;
        };

        return $modal;
    }

    
    protected function createComponentComment() : Task\Modules\Comment\Modals\CreateModal
    {
        $modal = $this->commentModalFactory->create();
        $modal->onFinish[] = function() {
            $this->reloadTheWholeGrid();

            $this->payload->scroll = false;
        };

        return $modal;
    }


    protected function createComponentBulkCommentAssign() : Task\Modules\Comment\Modals\BulkCommentModal
    {
        $modal = $this->bulkCommentModalFactory->create();
        $modal->onFinish[] = function() {
            $this->reloadTheWholeGrid();

            $this->payload->scroll = false;
        };

        return $modal;
    }

    
    protected function listenRow( ActiveRow $row, Html $tr ) : void
    {
        if ( $row->priority === TaskRow::PRIORITY_HIGH ) {
            $tr->setAttribute('class', ['table-danger']);
        } elseif ( $row->priority === TaskRow::PRIORITY_MEDIUM ) {
            $tr->setAttribute('class', ['table-warning']);
        } 
    }

}
