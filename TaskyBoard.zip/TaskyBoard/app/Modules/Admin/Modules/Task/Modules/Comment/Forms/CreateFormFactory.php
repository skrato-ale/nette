<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modules\Comment\Forms;

use App\Model\Task\TaskRow;

interface CreateFormFactory
{
    function create( TaskRow $task ) : CreateForm;
}