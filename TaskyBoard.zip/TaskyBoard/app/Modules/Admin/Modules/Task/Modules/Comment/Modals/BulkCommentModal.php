<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modules\Comment\Modals;

use App\Application\Events\Anchor;
use App\Model\Task\TaskRow;
use App\Modules\Admin\Modules\Task\Modules\Comment\Forms\BulkCommentForm;
use App\Modules\Admin\Modules\Task\Modules\Comment\Forms\BulkCommentFormFactory;
use App\Modules\Base\Modals\BatchModal;
use Nette\Application\Attributes\Persistent;
use Nette\DI\Attributes\Inject;

class BulkCommentModal extends BatchModal implements Anchor
{
    #[ Inject ]
    public BulkCommentFormFactory
        $bulkCommentFormFactory;

    #[ Persistent ]
    public string | null
        $task = null;

    /** @var TaskRow[] */
    protected array
        $taskRows;


    public function render() : void
    {
        $template = $this->getTemplate();
        $exists = $this->hasAnyTask();
        $template->exists = $exists;
        $template->render();
    }


    public function onAnchor() : void
    {
        $this->taskRows = $this->getRecords( TaskRow::TABLE, $this->task );
    }


    protected function createComponentForm() : BulkCommentForm
    {
        return $this->bulkCommentFormFactory->create( $this->taskRows );
    }


    protected function hasAnyTask() : bool
    {
        foreach( $this->taskRows as $task ) {
            if( $task->isTask() ) {
                return true;
            }
        }

        return false;
    }

}