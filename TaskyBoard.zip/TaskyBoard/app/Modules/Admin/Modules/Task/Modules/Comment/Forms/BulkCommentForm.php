<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modules\Comment\Forms;

use App\Application\Aspects\WriteAware;
use App\Dao\UserDAO;
use App\Model\Task\Comment\CommentManager;
use App\Model\Task\NoteManager;
use App\Model\Task\TaskManager;
use App\Model\Task\TaskRow;
use App\Modules\Admin\Modules\Task\Forms\TaskInputFactory;
use App\Modules\Base\Forms\DefineForm;
use Nette\DI\Attributes\Inject;

class BulkCommentForm extends DefineForm
{
    use WriteAware;

    #[ Inject ]
    public TaskInputFactory
        $taskInputFactory;

    #[ Inject ]
    public CommentManager
        $commentManager;

    #[ Inject ]
    public TaskManager
        $taskManager;

    #[ Inject ]
    public NoteManager
        $noteManager;

    #[ Inject ]
    public UserDAO
        $userDAO;

    /** @var TaskRow[] */
    protected array
        $taskRows;

    public function __construct( array $taskRows )
    {
        parent::__construct();

        $this->taskRows = $taskRows;

        $this->onSuccess[] = $this->onSuccess(...);
    }


    public function onStartup() : void
    {
        $list = $this->addContainer('note');

        $list->addTextArea('comment_text', 'Poznámka', rows: 4 )
            ->setNullable()
            ->addRule( $this::MaxLength, null, $this->commentManager->lengths['comment_text'] );

        $this->taskInputFactory->addBulkSet( $this );

        $this->addSubmit('btn', 'Přidat');
    }


    protected function onSuccess( self $form, array $post ): void
    {
        $taskData = array_filter( $post['task'], function( $value ) {
            return isset( $value );
        });

        $noteData = array_filter( $post['note'], function( $value ) {
            return isset( $value );
        });

        $this->tryCatchForm( function () use ( $taskData, $noteData ) {
            $user = $this->taskInputFactory->getAssignedRow( $taskData );
    
            foreach ($this->taskRows as $taskRow) {
                if( $taskRow->isTask() ) {
                    $this->taskManager->update($taskRow, $user, $taskData );
                } else {
                    $this->noteManager->update( $taskRow, $taskData );
                }
    
                if( isset( $noteData['comment_text'] )) {
                    $this->commentManager->create($taskRow, $noteData );
                }
            }
        });
    }    

}
