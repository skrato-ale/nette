<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modules\Comment\Forms;

use App\Application\Aspects\WriteAware;
use App\Model\Task\Comment\CommentManager;
use App\Model\Task\TaskManager;
use App\Model\Task\TaskRow;
use App\Modules\Admin\Modules\Task\Forms\TaskInputFactory;
use App\Modules\Base\Forms\DefineForm;
use Nette\DI\Attributes\Inject;

class CreateForm extends DefineForm
{
    use WriteAware;


    #[ Inject ]
    public TaskInputFactory
        $taskInputFactory;

    #[ Inject ]
    public CommentManager
        $commentManager;

    #[ Inject ]
    public TaskManager
        $taskManager;


    protected TaskRow
        $taskRow;


    public function __construct( TaskRow $task )
    {
        parent::__construct();

        $this->taskRow = $task;

        $this->onSuccess[] = $this->onSuccess(...);
        $this->onDefault[] = $this->onDefault(...);
    }



    public function onStartup() : void
    {
        $list = $this->addContainer('note');

        $list->addTextArea('comment_text', 'Poznámka', rows: 4 )
            ->setRequired()
            ->addRule( $this::MaxLength, null, $this->commentManager->lengths['comment_text'] );

        if( $this->taskRow->isTask() ) {
            $this->taskInputFactory->addCommentSet( $this );
        }

        $this->addSubmit('btn', 'Přidat');
    }


    protected function onSuccess( self $form, array $post ) : void
    {
        $this->tryCatchForm( function() use( $post ) {
            if( $this->taskRow->isTask() ) {
                $userRow = $this->taskInputFactory->getAssignedRow( $post['task'] );

                $this->taskManager->update( $this->taskRow, $userRow, $post['task'] );
            }

            $comment = $this->commentManager->create( $this->taskRow, $post['note'] );

            return [ $this->taskRow, $comment ];
        });
    }


    protected function onDefault() : array | null
    {
        if( !$this->taskRow->isTask() ) {
            return null;
        }

        $task = $this->taskRow->toArray();
        $task['start_date'] = $this->taskRow->start_date?->format('Y-m-d');
        $task['start_time'] = $this->taskRow->start_date?->format('H:i');

        return [
            'task'  => $task
        ];
    }
}