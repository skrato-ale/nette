<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modules\Comment\Forms;

interface BulkCommentFormFactory
{
    function create( array $taskRows ) : BulkCommentForm;
}