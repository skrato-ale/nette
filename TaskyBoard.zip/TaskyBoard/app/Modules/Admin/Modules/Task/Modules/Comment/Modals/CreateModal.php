<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modules\Comment\Modals;

use App\Application\Events\Anchor;
use App\Model\Task\TaskManager;
use App\Model\Task\TaskRow;
use App\Modules\Admin\Modules\Task\Modules\Comment\Forms\CreateForm;
use App\Modules\Admin\Modules\Task\Modules\Comment\Forms\CreateFormFactory;
use App\AdminModule\Components\ModalControl;
use Nette\Application\Attributes\Persistent;
use Nette\DI\Attributes\Inject;

class CreateModal extends ModalControl implements Anchor
{
    #[ Inject ]
    public CreateFormFactory
        $createFormFactory;

    #[ Inject ]
    public TaskManager
        $taskManager;


    #[ Persistent ]
    public int | null
        $task = null;


    protected TaskRow
        $taskRow;


    public function render() : void
    {
        $template = $this->getTemplate();
        $template->task = $this->taskRow;
        $template->render();
    }


    public function onAnchor() : void
    {
        $task = $this->taskManager->find( $this->task ?? $this->error() );

        $this->taskRow = $task ?? $this->error();
    }


    protected function createComponentForm() : CreateForm
    {
        return $this->createFormFactory->create( $this->taskRow );
    }
}