<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Modules\Comment\Modals;

interface CreateModalFactory
{
    function create() : CreateModal;
}