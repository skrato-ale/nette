<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Task\Controls;

use App\Application\Events\Anchor;
use App\Dao\Model\User;
use App\Model\Task\TaskRow;
use App\Modules\Admin\Modules\Task;
use Nette\Application\UI\Control;
use Nette\Database\Explorer;
use Nette\DI\Attributes\Inject;

/** @todo rewrite parameter handling */
class TaskSideDetailControl extends Control implements Anchor
{
    #[ Inject ]
    public Task\Modules\Comment\Forms\CreateFormFactory
        $commentFormFactory;

    #[ Inject ]
    public Task\Modals\UpdateModalFactory
        $updateModalFactory;

    #[ Inject ]
    public Task\Forms\StatusFormFactory
        $statusFormFactory;

    #[ Inject ]
    public Explorer
        $explorer;


    protected TaskRow | null
        $task = null;

    public int|null $taskId = null;

    public array $comments = [];

    public bool $isShowDetailButton = true;

    public function __construct( int | null $taskId, TaskRow | null $taskRow, $isShowDetailButton )
    {
        $this->taskId = $taskId;
        $this->isShowDetailButton = $isShowDetailButton;

    }

    public function onAnchor() : void
    {
        if ( $this->taskId ) {
            $this->getTask();
            $this->getComments();
        }
    }

    public function render() : void
    {
        $template = $this->getTemplate();
        $template->task = $this->task;
        $template->comments = $this->comments;
        $template->isShowDetailButton = $this->isShowDetailButton;
        $template->render( __DIR__ . '/templates/taskSideDetail.latte');
    }

    protected function createComponentCommentForm() : Task\Modules\Comment\Forms\CreateForm
    {
        $ctrl = $this->commentFormFactory->create( $this->task );
        $ctrl->onFinish[] = function() {
            $this->getPresenter()->redirect('this');
        };
        
        return $ctrl;
    }

    protected function createComponentStateForm() : Task\Forms\StatusForm
    {
        $ctrl = $this->statusFormFactory->create( $this->task );
        $ctrl->onFinish[] = function() {
            $this->getPresenter()->redirect('this');
        };
        
        return $ctrl;
    }


    public function handleUpdate( string $id ) : void
    {
        $this->getPresenter()->initModal( $this, 'update', ['task' => $id ]);
    }


    protected function createComponentUpdate() : Task\Modals\UpdateModal
    {
        $modal = $this->updateModalFactory->create();
        $modal->onFinish[] = function() {
            $this->redirect('this');
        };

        return $modal;
    }

    
    private function getTask(): void
    {
        $this->task = $this->explorer->table('task')->get($this->taskId);
    }
    
    private function getComments(): void
    {
        $this->comments = $this->explorer->table('task_comment')
            ->where('task_id = ?', $this->taskId)
            ->fetchAll();
    }

}