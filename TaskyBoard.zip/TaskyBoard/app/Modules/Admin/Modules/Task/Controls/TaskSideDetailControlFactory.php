<?php declare( strict_types=1 );

namespace App\Modules\Admin\Modules\Task\Controls;

use App\Model\Task\TaskRow;

interface TaskSideDetailControlFactory
{
    function create( int | null $taskId, TaskRow | null $taskRow, bool $isShowDetailButton = true ) : TaskSideDetailControl;
}