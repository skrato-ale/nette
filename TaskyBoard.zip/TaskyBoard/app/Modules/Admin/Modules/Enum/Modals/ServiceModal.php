<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Enum\Modals;

use App\Application\Aspects\WriteAware;
use App\Application\Events\Anchor;
use App\Dao\EnumPersonServicesDAO;
use App\Modules\Base\Forms\Form;
use App\Modules\Base\Forms\LayoutFormFactory;
use App\AdminModule\Components\ModalControl;
use Nette\Application\Attributes\Persistent;
use Nette\Database\Table\ActiveRow;
use Nette\DI\Attributes\Inject;
use Nette\Forms\Controls\BaseControl;

class ServiceModal extends ModalControl implements Anchor
{
    use WriteAware;

    #[Inject]
    public LayoutFormFactory $layoutFormFactory;

    #[Inject]
    public EnumPersonServicesDAO $enumPersonServicesDAO;

    protected ?ActiveRow $service = null;

    #[ Persistent() ]
    public ?int $serviceId = null;

    public function __construct()
    {
        parent::__construct();
    }

    public function onAnchor(): void
    {
        if( $this->serviceId ) {
            $this->service = $this->enumPersonServicesDAO->find($this->serviceId);
        }
    }

    public function render(): void
    {
        /** @var DefaultTemplate $template */
        $template = $this->getTemplate();
        $template->serviceId = $this->serviceId;
        $template->render(__DIR__ . '/templates/service-modal.latte');
    }

    protected function createComponentForm(): Form
    {
        $form = $this->layoutFormFactory->create();
        $form->addText('enum_key', 'Klíč');
        $form->addText('translation_key', 'Klíč překladu')->addRule(function (
            BaseControl $input,
            $arg
        ) {
            return str_starts_with($input->getValue(), 'enum.personServices.');
        }, 'start_with')
        ->setDefaultValue('enum.personServices.');
        $form->addSubmit('submit', 'Uložit');

        if ($this->service) {
            $form->setDefaults($this->service->toArray());
        } 

        $form->onSuccess[] = [$this, 'process'];
        return $form;
    }

    public function process(Form $form, array $data): void
    {
        $this->tryCatchModal(function() use ($data) {
            if ($this->service) {
                $this->service->update($data);
            } else {
                $this->enumPersonServicesDAO->insert($data);
            }

            return $this->service;
        });
    }

}
