<?php declare(strict_types=1);

namespace App\Modules\Admin\Modules\Enum\Grids;

use App\Application\Aspects\WriteAware;
use App\Dao\EnumPersonServicesDAO;
use App\Helpers\Cast;
use App\Modules\Base\Grids\DefineGrid;
use Nette\Database\Table\Selection;
use Nette\DI\Attributes\Inject;

class ServiceGrid extends DefineGrid
{
    use WriteAware;

    #[ Inject ]
    public EnumPersonServicesDAO $enumPersonServicesDAO;

    public function __construct( )
    {
        parent::__construct();

    }


    protected function createSelection() : Selection
    {
        $query = $this->enumPersonServicesDAO->getTable();

        return $query;
    }


    public function onStartup() : void
    {
        $this->setDefaultSort(['id' => 'ASC']);

        $this->addColumnText('id', 'Id')
            ->setSortable()
            ->setFilterText('id')
            ->setExactSearch();

        $this->addColumnText('enum_key', 'Key')
            ->setFilterText('enum_key');

        $this->addActionCallback('edit', 'Upravit', $this->handleServiceModal(...))
            ->setClass( $this->getCustomClass('btn', 'btn-sec', 'ajax'));
    }

    public function handleServiceModal( string $id ) : void
    {
        $id = Cast::id( $id ) ?? $this->error();

        $this->getPresenter()->initModal( null, 'serviceModal', ['serviceId' => $id ]);
    }

}