<?php

namespace App\AdminModule\Presenters;

use App\Modules\Admin\Modules\Enum\Grids\ServiceGrid;
use App\Modules\Admin\Modules\Enum\Grids\ServiceGridFactory;
use App\Modules\Admin\Modules\Enum\Modals\ServiceModal;
use App\Modules\Admin\Modules\Enum\Modals\ServiceModalFactory;
use Nette\DI\Attributes\Inject;

class EnumPresenter extends BasePresenter
{
    #[Inject]
    public ServiceModalFactory $serviceModalFactory;

    #[Inject]
    public ServiceGridFactory $serviceGridFactory;


    public function createComponentServiceGrid(): ServiceGrid
    {
        return $this->serviceGridFactory->create();
    }


    protected function createComponentServiceModal() : ServiceModal
    {
        $ctrl = $this->serviceModalFactory->create( );
        $ctrl->onFinish[] = function($service) {
            if ($service) {
                $this->flashMessage('Služba byla upravena');
            } else {
                $this->flashMessage('Služba byla vytvořena');
            }
            $this->redirect('services');
        };

        return $ctrl;
    }
    
}
