<?php

namespace App\AdminModule\Presenters;

use App\Dao\TaskCommentDAO;
use App\Dao\TaskDAO;
use App\Dao\TaskHistoryDAO;
use App\Modules\Admin\Modules\Task\Controls\TaskSideDetailControl;
use App\Modules\Admin\Modules\Task\Controls\TaskSideDetailControlFactory;
use App\Modules\Admin\Modules\Task\Grids\TaskGrid;
use App\Modules\Admin\Modules\Task\Grids\TaskGridFactory;
use App\Service\TaskColorFilter;
use App\Service\TaskService;
use Nette\Application\Attributes\Persistent;
use Nette\DI\Attributes\Inject;

class TaskPresenter extends BasePresenter
{
    #[ Inject ]
    public TaskGridFactory $taskGridFactory;

    #[Inject]
    public TaskService $taskService;

    #[Inject]
    public TaskDAO $taskDAO;

    #[Inject]
    public TaskCommentDAO $taskCommentDAO;

    #[Inject]
    public TaskHistoryDAO $taskHistoryDAO;

    #[Inject]
    public TaskSideDetailControlFactory $taskSideDetailControlFactory;

    #[Persistent]
    public $onlyMyTasks = 0;

    #[Persistent]
    public int | null $selectedTaskId = null;

    public bool $isShowDetailButton = true;

    protected function startup()
    {
        parent::startup();

        $id = $this->getParameter('id');

        if( $id ) {
            $this->selectedTaskId = $id;
            $this->isShowDetailButton = false;
        }
    }


    public function renderDefault(): void
    {

    }


    public function renderDetail( int $id ) : void
    {
        $task = $this->taskDAO->find($id) ?? $this->error();

        $this->template->task = $task;
        $this->template->comments = $this->taskCommentDAO->findBy(['task_id' => $id],'created DESC')->fetchAll();
    }

    public function renderCalendarForUser(): void
    {
        $this->template->tasks = $this->taskService->getAllForCalendarUser($this->getUser()->id);
        $this->template->calendarUser = $this->getUser();
        $this->template->addFilter('getTaskColor', [TaskColorFilter::class, 'getTaskColor']);
    }


    public function createComponentTaskGrid() : TaskGrid
    {
        $grid = $this->taskGridFactory->create();
        if ($this->onlyMyTasks) {
            $grid->setFromUser( $this->getCoreUser(), assign: true );
        }

        return $grid;
    }

    public function renderCalendarForAdmin(): void
    {
        $ids = $this->getParameter('users', []);

        if (empty($ids)) {
            $tasks = $this->taskService->getAllForCalendar();
        } else {
            $tasks = $this->taskService->getAllByUserIdsForCalendar($ids);
        }

        $this->template->tasks = $tasks;
        $this->template->selectedUsers = $ids;
        $this->template->calendarUser = $this->getUser()->id;
        $this->template->users = $this->userDAO->getUsersForCalendar();
        $this->template->addFilter('getTaskColor', [TaskColorFilter::class, 'getTaskColor']);
    }


    public function createComponentTaskSideDetail() : TaskSideDetailControl
    {
        $sideDetail = $this->taskSideDetailControlFactory->create( $this->selectedTaskId, null, $this->isShowDetailButton );

        return $sideDetail;
    }


    public function handleSelectedTask($taskId)
    {
        $this->selectedTaskId = $taskId;
        $this->redrawControl('sideDetailSnippet');
    }

}
