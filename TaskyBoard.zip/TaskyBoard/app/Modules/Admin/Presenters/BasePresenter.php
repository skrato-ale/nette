<?php

namespace App\AdminModule\Presenters;

use App\AdminModule\Components\Sidebar\ISidebarFactory;
use App\Enums\UserRoleEnum;
use App\Modules\Base\Forms\Form;
use App\Presenters\AjaxPresenter;
use Nette\DI\Attributes\Inject;

abstract class BasePresenter extends AjaxPresenter
{
    #[Inject]
    public ISidebarFactory $sidebarFactory;

    protected function startup()
    {
        parent::startup();

        $user = $this->watchUser();

        $roles = [
            UserRoleEnum::ROLE_CUSTOMER,
            UserRoleEnum::ROLE_PARTNER,
        ];

        foreach( $roles as $role ) {
            if( $user->isInRole( UserRoleEnum::getName( $role ))) {
                $this->redirect(':App:Home:default');
            }
        }

        if( !$this instanceof SignPresenter ) {
            if( !$user->isLoggedIn() ) {
                $this->redirect(':Admin:Sign:in', ['key' => $this->storeRequest() ]);
            }

            if( !$this->user->isAllowed( $this->getName(), $this->getAction() )) {
                $this->forbidden();
            }
        }

        $userEntity = $this->getCoreUser();

        if( $userEntity and $userEntity->isBlocked() ) {
            $user->logout(true);

            $this->redirect(':App:Home:default');
        }
    }


    public function beforeRender()
    {
        parent::beforeRender();

        $this->template->getLatte()->addFilterLoader([new \App\Service\CMSFilters(), 'load']);
    }

    public function translate($key)
    {
        return $this->translator->translate($key);
    }

    public function createComponentSidebar()
    {
        return $this->sidebarFactory->create();
    }

    function formBootstrap5(Form &$form): void
    {
        $renderer = $form->getRenderer();
        $renderer->wrappers['controls']['container'] = null;
        $renderer->wrappers['pair']['container'] = 'div class="form-group row"';
        $renderer->wrappers['pair']['.error'] = 'has-danger';
        $renderer->wrappers['control']['container'] = 'div class=col-sm-9';
        $renderer->wrappers['label']['container'] = 'div class="col-sm-3 col-form-label"';
        $renderer->wrappers['control']['description'] = 'span class=form-text';
        $renderer->wrappers['control']['errorcontainer'] = 'span class=form-control-feedback';
        $renderer->wrappers['control']['.error'] = 'is-invalid';

        foreach ($form->getControls() as $control) {
            $type = $control->getOption('type');
            if ($type === 'button') {
                $control->getControlPrototype()->addClass(empty($usedPrimary) ? 'btn btn-primary' : 'btn btn-secondary');
                $usedPrimary = true;

            } elseif ($type == 'text') {
                $control->getControlPrototype()->addClass('form-control');

            } elseif ($type == 'textarea') {
                $control->getControlPrototype()->addClass('form-control');

            } elseif ($type == 'select') {
                $control->getControlPrototype()->addClass('form-select');

            } elseif ($type === 'file') {
                $control->getControlPrototype()->addClass('form-control-file');

            } elseif (in_array($type, ['checkbox', 'radio'], true)) {
                if ($control instanceof Nette\Forms\Controls\Checkbox) {
                    $control->getLabelPrototype()->addClass('form-check-label');
                } else {
                    $control->getLabelPrototype()->addClass('form-check-label');
                }
                $control->getControlPrototype()->addClass('form-check-input');
                $control->getSeparatorPrototype()->setName('div')->addClass('form-check');
            }
        }
    }

}
