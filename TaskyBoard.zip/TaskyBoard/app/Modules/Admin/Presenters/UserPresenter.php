<?php

namespace App\AdminModule\Presenters;

use App\Dao\Model\User;
use App\Dao\TaskDAO;
use App\Dao\UserDAO;
use App\Helpers\Cast;
use App\Modules\Admin;
use App\Modules\Admin\Modules\Task\Grids\TaskGrid;
use App\Modules\Admin\Modules\Task\Grids\TaskGridFactory;
use App\Modules\Admin\Modules\Task\Modals\CreateModal;
use App\Modules\Admin\Modules\Task\Modals\CreateModalFactory;
use App\Modules\Admin\Modules\User\Grids\UserGridFactory;
use App\Modules\Admin\Modules\User\Modals\DeleteUserModal;
use App\Modules\Admin\Modules\User\Modals\DeleteUserModalFactory;
use App\Modules\Base\Forms\Form;
use App\Service\ResetPasswordTokenService;
use App\Service\UserService;
use Nette\Database\Table\ActiveRow;
use Nette\DI\Attributes\Inject;

class UserPresenter extends BasePresenter
{
    #[ Inject ]
    public UserGridFactory $userGridFactory;

    #[ Inject ]
    public TaskGridFactory $taskUserGridFactory;

    #[ Inject ]
    public CreateModalFactory $taskCreateModalFactory;

    #[Inject]
    public UserDAO $userDAO;

    #[Inject]
    public UserService $userService;

    #[Inject]
    public TaskDAO $taskDAO;

    #[Inject]
    public ResetPasswordTokenService $resetPasswordTokenService;

    #[Inject]
    public DeleteUserModalFactory $deleteUserModalFactory;

    private ActiveRow | null $userRow = null;

    private User | null $coreUser = null;

    protected function startup()
    {
        parent::startup();

        $id = $this->getParameter('id');

        if( $id ) {
            $user = $this->userDAO->find( Cast::id( $id ) ?? $this->error() );

            $person = $user?->related('admin_person')->fetch();

            $this->userRow = $user ?? $this->error();
            $this->personRow = $person ?? $this->error();
            $this->coreUser = User::from( $user );
        }
    }


    public function beforeRender(): void
    {
        parent::beforeRender();

        $this->template->userPerson = $this->coreUser;

        if ($this->coreUser) {
            $userId = $this->coreUser->id;
            $this->template->tasksCount = $this->taskDAO->getNotesForAdmin($userId)->count('*');
        }

    }

    public function actionDetail( int $id ) : void
    {

    }

    public function renderDefault(): void
    {

    }


    public function renderUser(): void
    {

    }


    public function actionTasks( int $id ) : void
    {

    }


    public function createComponentUserGrid() : Admin\Modules\User\Grids\UserGrid
    {
        return $this->userGridFactory->create();
    }


    public function createComponentNotesGrid() : TaskGrid
    {
        $grid = $this->taskUserGridFactory->create();
        $grid->setFromUser( $this->coreUser, global: true );

        return $grid;
    }


    public function createComponentChangePasswordForm()
    {
        $form = new Form();
        $form->addPassword('password', 'Nové heslo');
        $form->addPassword('password_confirm', 'Opakovat nové heslo')
            ->setRequired('polozka je povinna')
            ->addConditionOn($form['password'], $form::FILLED, true)
            ->addRule($form::EQUAL, 'Hodnoty musí být stejné',$form['password']);
        $form->addSubmit('send', 'Odeslat')
            ->onClick[] = [$this, 'changePasswordFormSucceeded'];

        return $form;
    }

    public function changePasswordFormSucceeded($button)
    {
        if ($button->name === 'send') {
            $values = $button->getForm()->getValues();
            $user = User::from($this->userDAO->find($this->getParameter('id')));

            $user->setFromArray(['password' => $values->password]);
            $this->userService->update($user);
        }
    }


    protected function createComponentDeleteUserModal() : DeleteUserModal
    {
        $ctrl = $this->deleteUserModalFactory->create( $this->userRow ?? $this->error(), $this->getCoreUser() );
        $ctrl->onFinish[] = function() {
            $this->flashMessage('Uživatel byl smazán');
            $this->redirect('this');
        };

        return $ctrl;
    }

    protected function createComponentTaskCreate() : CreateModal
    {
        $ctrl = $this->taskCreateModalFactory->create( $this->userRow ?? $this->error() );
        $ctrl->onFinish[] = function() {
            $this->flashMessage('Byl vytvořen úkol nebo poznámka');
            $this->redirect('this');
        };

        return $ctrl;
    }
}
