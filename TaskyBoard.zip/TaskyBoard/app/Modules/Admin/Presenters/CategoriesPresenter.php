<?php

namespace App\AdminModule\Presenters;

use App\Dao\CategoryDAO;
use App\Modules\Admin\Modules\Category\Modals\CategoryEditModal;
use App\Modules\Admin\Modules\Category\Modals\CategoryEditModalFactory;
use Nette\DI\Attributes\Inject;

class CategoriesPresenter extends BasePresenter
{
    #[Inject]
    public CategoryDAO $categoryDAO;

    #[Inject]
    public CategoryEditModalFactory $categoryEditMofalFactory;


    public function renderEditCategory(): void
    {
        $id = $this->getParameter('id');

        $cat = null;
        if ($id !== null) {
            $cat = $this->categoryDAO->find($id);
        }

        $this->template->cat = $cat;
    }


    protected function createComponentCategoryEditModal() : CategoryEditModal
    {
        $ctrl = $this->categoryEditMofalFactory->create( );
        $ctrl->onFinish[] = function() {
            $this->flashMessage('Úprava dokončena', 'success');
            $this->redirect('default');
        };
        return $ctrl;
    }

}