<?php

namespace App\AdminModule\Components\Sidebar;

use App\Dao\TaskDAO;
use App\Enums\TaskStateEnum;
use Nette\Application\UI\Control;

final class Sidebar extends Control
{

    public function __construct(
        public TaskDAO  $taskDAO
    )
    {
    }

    public function render(): void
    {
        $loggedUserId = $this->getPresenter()->getUser()->id;
        $viewModel = $this->getPresenter()->createTemplate();
        $viewModel->control = $this;
        $viewModel->myTasksCount = $this->taskDAO->countBy(['assigned_to_id ' => $loggedUserId, 'task_state' => TaskStateEnum::NEW]);        
        $viewModel->allTasksCount = $this->taskDAO->countBy(['task_state' => TaskStateEnum::NEW]);
        $viewModel->setFile(__DIR__ . '/sidebar.latte');
        $viewModel->render();
    }
}

interface ISidebarFactory
{
    public function create(): Sidebar;
}
