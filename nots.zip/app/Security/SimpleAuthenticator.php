<?php
declare(strict_types=1);

namespace App\Security;

use Nette\Security\Authenticator;
use Nette\Security\Identity;
use Nette\Security\AuthenticationException;
use Nette\Database\Explorer;

final class SimpleAuthenticator implements Authenticator
{
    private Explorer $db;

    public function __construct(Explorer $db)
    {
        $this->db = $db;
    }

    public function authenticate(string $username, string $password): Identity
    {
        $row = $this->db->table('users')->where('email', $username)->fetch();
        if (!$row || !password_verify($password, $row->password_hash)) {
            throw new AuthenticationException('Neplatné přihlašovací údaje.');
        }
        return new Identity($row->id, [], ['email' => $row->email]);
    }
}
