<?php
declare(strict_types=1);

namespace App\Router;

use Nette;
use Nette\Application\Routers\RouteList;
use Nette\Application\Routers\Route;

final class RouterFactory
{
    public static function createRouter(): RouteList
    {
        $router = new RouteList;
        $router->addRoute('login', 'Auth:login');
        $router->addRoute('logout', 'Auth:logout');
        $router->addRoute('<presenter>/<action>[/<id>]', 'Note:default');
        return $router;
    }
}
