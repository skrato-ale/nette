<?php
declare(strict_types=1);

namespace App\Presenters;

use App\Model\Note;
use Nette;
use Nette\Application\UI\Form;

final class NotePresenter extends BasePresenter
{
    private Note $noteModel;

    public function __construct(Note $noteModel)
    {
        $this->noteModel = $noteModel;
    }

    public function startup(): void
    {
        parent::startup();
        if (!$this->getUser()->isLoggedIn()) {
            $this->redirect('Auth:login');
        }
    }

    public function renderDefault(): void
    {
        $this->template->notes = $this->noteModel->getByUser($this->getUser()->getId());
    }

    public function actionEdit(int $id): void
    {
        $note = $this->noteModel->get($id, $this->getUser()->getId());
        if (!$note) {
            $this->error('Poznámka nenalezena.');
        }
        $this['noteForm']->setDefaults($note);
    }

    public function actionDelete(int $id): void
    {
        $this->noteModel->delete($id, $this->getUser()->getId());
        $this->redirect('default');
    }

    protected function createComponentNoteForm(): Form
    {
        $form = new Form;
        $form->addText('title', 'Titulek:')
            ->setMaxLength(100);
        $form->addTextArea('content', 'Obsah:')
            ->setRequired('Obsah je povinný.')
            ->addRule($form::MIN_LENGTH, 'Obsah musí mít alespoň %d znaků.', 10);
        $form->addSubmit('send', 'Uložit');
        $form->onSuccess[] = [$this, 'noteFormSucceeded'];
        $form->addProtection();
        return $form;
    }

    public function noteFormSucceeded(Form $form, \stdClass $values): void
    {
        $id = $this->getParameter('id');
        if ($id) {
            $this->noteModel->update((int) $id, $this->getUser()->getId(), $values);
            $this->flashMessage('Poznámka upravena.');
        } else {
            $this->noteModel->insert($this->getUser()->getId(), $values);
            $this->flashMessage('Poznámka přidána.');
        }
        $this->redirect('default');
    }
}
