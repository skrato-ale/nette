<?php
declare(strict_types=1);

namespace App\Presenters;

use Nette;
use Nette\Application\UI\Form;

final class AuthPresenter extends BasePresenter
{
    protected function createComponentLoginForm(): Form
    {
        $form = new Form;
        $form->addText('email', 'Email:')->setRequired();
        $form->addPassword('password', 'Heslo:')->setRequired();
        $form->addSubmit('send', 'Přihlásit se');
        $form->onSuccess[] = [$this, 'loginFormSucceeded'];
        return $form;
    }

    public function loginFormSucceeded(Form $form, \stdClass $values): void
    {
        try {
            $this->getUser()->login($values->email, $values->password);
            $this->redirect('Note:');
        } catch (Nette\Security\AuthenticationException $e) {
            $form->addError('Neplatné přihlašovací údaje.');
        }
    }

    public function actionLogout(): void
    {
        $this->getUser()->logout();
        $this->redirect('login');
    }
}
