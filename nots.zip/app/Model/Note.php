<?php
declare(strict_types=1);

namespace App\Model;

use Nette\Database\Explorer;

final class Note
{
    private Explorer $db;

    public function __construct(Explorer $db)
    {
        $this->db = $db;
    }

    public function getByUser(int $userId)
    {
        return $this->db->table('notes')->where('user_id', $userId)->order('created_at DESC');
    }

    public function get(int $id, int $userId)
    {
        return $this->db->table('notes')->where('id', $id)->where('user_id', $userId)->fetch();
    }

    public function insert(int $userId, \stdClass $data): void
    {
        $this->db->table('notes')->insert([
            'user_id' => $userId,
            'title' => $data->title,
            'content' => $data->content
        ]);
    }

    public function update(int $id, int $userId, \stdClass $data): void
    {
        $this->get($id, $userId)?->update([
            'title' => $data->title,
            'content' => $data->content
        ]);
    }

    public function delete(int $id, int $userId): void
    {
        $this->get($id, $userId)?->delete();
    }
}
