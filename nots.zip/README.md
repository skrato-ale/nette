# Nette Poznámky

Jednoduchá CRUD aplikace pro správu poznámek s přihlášením.

## Instalace

1. `composer install`
2. Vytvořte databázi a importujte `db/init.sql`
3. Spusťte `php -S localhost:8000 -t www`

Přihlášení: `admin@demo.cz` / `heslo123`
